@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\pythonw.exe" (
  start "" "%~dp0INSTALL_AND_RUN.bat"
  exit /b
)
start "Trading AI Desktop" ".venv\Scripts\pythonw.exe" "run_desktop.py"
