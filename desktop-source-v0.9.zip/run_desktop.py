"""Native Windows entrypoint. --selftest checks the bundled TradingAgents imports."""
from __future__ import annotations
import sys

if __name__ == '__main__':
    if '--selftest' in sys.argv:
        from trading_ai_desktop.ai import tradingagents_installed, tradingagents_config
        try:
            ready = tradingagents_installed()
            config = tradingagents_config() if ready else {}
            good = ready and config.get('llm_provider') == 'chatgpt'
        except Exception:
            good = False
        raise SystemExit(0 if good else 7)
    from trading_ai_desktop.app import main
    main()
