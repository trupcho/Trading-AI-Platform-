"""First-run wizard for the local Windows MT5 application.

The wizard never persists broker passwords and NEVER submits broker orders.
MetaTrader 5 is a separate licensed program, which must be installed on
Windows, normally from the user's own broker.
"""
from __future__ import annotations

import os
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from typing import Mapping
import webbrowser

OANDA_MT5_GUIDE = "https://help.oanda.com/eu/en/faqs/mt5-user-guide-eu.htm"

# The executable distributed by MetaQuotes is usually *terminal64.exe*,
# not metatrader64.exe. A broker may use a custom program directory.
TERMINAL_NAMES = ("terminal64.exe", "terminal.exe")


def find_mt5_terminals(environ: Mapping[str, str] | None = None) -> list[str]:
    """Find familiar MT5 Windows installations without launching any executables.

    Only shallow directory scans are used. A browse control covers custom paths.
    """
    env = os.environ if environ is None else environ
    roots = [Path(p) for p in (
        env.get("PROGRAMFILES", ""),
        env.get("PROGRAMFILES(X86)", ""),
        str(Path(env.get("LOCALAPPDATA", "")) / "Programs") if env.get("LOCALAPPDATA") else "",
    ) if p]
    matches: list[str] = []
    seen: set[str] = set()
    for root in roots:
        if not root.is_dir():
            continue
        # Broker folders often include the product name but not necessarily MT5.
        # Search one directory level; never recurse into the entire Program Files.
        for name in TERMINAL_NAMES:
            try:
                candidates = [root / name, *(root.glob("*/" + name))]
            except OSError:
                continue
            for candidate in candidates:
                try:
                    if candidate.is_file():
                        key = str(candidate.resolve()).casefold()
                        if key not in seen:
                            matches.append(str(candidate))
                            seen.add(key)
                except OSError:
                    continue
    return matches


def valid_terminal_path(path: str) -> bool:
    """Accepted executable filenames only; no implicit executing of arbitrary files."""
    p = Path(path.strip())
    return bool(p.name.lower() in TERMINAL_NAMES and p.is_file())


class SetupWizard(tk.Toplevel):
    """One-place flow: terminal check -> broker login -> read-only diagnostics."""

    def __init__(self, app):
        super().__init__(app)
        self.app = app
        self.title("Trading AI · Първоначална настройка")
        self.geometry("730x580")
        self.minsize(640, 510)
        self.configure(bg="#0c121d")
        self.protocol("WM_DELETE_WINDOW", self._close)
        self.step = 0
        self.status = tk.StringVar(value="Проверка на MT5 терминала…")
        self.diagnostic_result = None
        self._build()
        self._refresh_terminal()
        self.show_step(0)
        self.transient(app)
        self.lift()

    def _label(self, parent, text, *, size=11, color="#f5f6fa", bold=False, wrap=None):
        return tk.Label(parent, text=text, bg="#0c121d", fg=color,
                        font=("Segoe UI", size, "bold" if bold else "normal"),
                        justify="left", anchor="w", wraplength=wrap)

    def _build(self):
        panel = tk.Frame(self, bg="#0c121d")
        panel.pack(fill="both", expand=True, padx=29, pady=22)
        self._label(panel, "TRADING AI", size=19, color="#e8c075", bold=True).pack(anchor="w")
        self._label(panel, "Настройка на компютъра", size=22, bold=True).pack(anchor="w", pady=(8, 7))
        self._label(panel, "Една брокерска регистрация. Trading AI управлява интерфейса, а MT5 изпълнява поръчките.",
                    size=10, color="#a4b6c9", wrap=650).pack(anchor="w")
        self.step_head = self._label(panel, "", size=14, bold=True)
        self.step_head.pack(anchor="w", pady=(25, 9))
        self.content = tk.Frame(panel, bg="#0c121d")
        self.content.pack(fill="both", expand=True)
        footer = tk.Frame(panel, bg="#0c121d")
        footer.pack(fill="x", pady=(10, 0))
        self._label(footer, "Паролата не се записва в Trading AI. Реалните поръчки са забранени.",
                    color="#ff9696", size=9, wrap=450).pack(side="left")
        self.next_button = ttk.Button(footer, text="Продължи", command=self.next_step)
        self.next_button.pack(side="right")
        self.back_button = ttk.Button(footer, text="Назад", command=self.prev_step)
        self.back_button.pack(side="right", padx=8)
        self._label(panel, "Етап 1/3: MT5  ·  Етап 2/3: Демо акаунт  ·  Етап 3/3: Проверка",
                    size=9, color="#a4b6c9").pack(anchor="e", pady=(7, 0))

    def _clear(self):
        for child in list(self.content.winfo_children()):
            child.destroy()

    def _button(self, parent, label, command):
        b = ttk.Button(parent, text=label, command=command)
        b.pack(anchor="w", pady=7)
        return b

    def _refresh_terminal(self):
        manual = self.app.terminal.get().strip()
        if manual and valid_terminal_path(manual):
            self.status.set("MT5 терминалът е открит: " + manual)
            return
        found = find_mt5_terminals()
        if found:
            self.app.terminal.set(found[0])
            self.status.set("MT5 терминалът е открит: " + found[0])
        else:
            self.status.set("MT5 не е открит автоматично. Инсталирай го от брокера или избери файла terminal64.exe.")

    def _browse(self):
        path = filedialog.askopenfilename(
            parent=self, title="Избери MT5 terminal64.exe",
            filetypes=[("MetaTrader 5", "terminal64.exe terminal.exe"), ("Windows програми", "*.exe")],
        )
        if path:
            if not valid_terminal_path(path):
                messagebox.showwarning("MT5 терминал", "Избери terminal64.exe или terminal.exe от MetaTrader 5.", parent=self)
            else:
                self.app.terminal.set(path)
        self._refresh_terminal()

    def _open_mt5(self):
        path = self.app.terminal.get().strip()
        if valid_terminal_path(path):
            try:
                os.startfile(path)  # Windows-only; invoked by an explicit user click.
            except (OSError, AttributeError):
                messagebox.showerror("MT5", "Не мога да стартирам терминала. Отвори го ръчно.", parent=self)
        else:
            messagebox.showinfo("MT5", "Първо открий MT5 терминала или го инсталирай.", parent=self)

    def show_step(self, number: int):
        self.step = max(0, min(2, number))
        self._clear()
        self.back_button.configure(state="normal" if self.step else "disabled")
        if self.step == 0:
            self._step_terminal()
        elif self.step == 1:
            self._step_account()
        else:
            self._step_diagnostics()

    def _step_terminal(self):
        self.step_head.config(text="1 / 3  ·  MetaTrader 5")
        self._label(self.content, "MetaTrader 5 е техническата връзка с брокера. Не се изисква отделна регистрация в MT5.",
                    color="#a4b6c9", wrap=630).pack(anchor="w", pady=(0, 12))
        self._label(self.content, "Състояние:", bold=True).pack(anchor="w")
        tk.Label(self.content, textvariable=self.status, bg="#0c121d", fg="#e8c075",
                 font=("Segoe UI", 10), wraplength=620, justify="left").pack(anchor="w", pady=8)
        self._button(self.content, "Провери пак за MT5", self._refresh_terminal)
        self._button(self.content, "Изтегли MT5 от официалната страница на OANDA", lambda: webbrowser.open(OANDA_MT5_GUIDE))
        self._button(self.content, "Посочи вече инсталиран MT5 (terminal64.exe)", self._browse)
        self._button(self.content, "Отвори MT5", self._open_mt5)
        self.next_button.config(text="Продължи")

    def _step_account(self):
        self.step_head.config(text="2 / 3  ·  Демо сметка")
        self._label(self.content, "Въведи данните за MT5 от брокера. Полетата не се изпращат към GitHub или ChatGPT.",
                    color="#a4b6c9", wrap=630).pack(anchor="w", pady=(0, 10))
        for title, var, secret in (
            ("MT5 номер на сметка", self.app.login, False),
            ("Server (точното име от брокера)", self.app.server, False),
            ("MT5 парола", self.app.password, True),
        ):
            self._label(self.content, title, size=10).pack(anchor="w", pady=(8, 4))
            e = ttk.Entry(self.content, textvariable=var, show="•" if secret else "", width=53)
            e.pack(anchor="w", fill="x", padx=(0, 45))
        self._label(self.content, "За първи тест: само DEMO. REAL сметки са в режим наблюдение.",
                    color="#e8c075", size=10).pack(anchor="w", pady=(14, 0))
        self.next_button.config(text="Свържи и провери")

    def _step_diagnostics(self):
        self.step_head.config(text="3 / 3  ·  Проверка на брокерската връзка")
        if self.app.connected:
            mode = "DEMO" if self.app.demo else "REAL (наблюдение)"
            self._label(self.content, "MT5 е свързан: " + mode, color="#65d9ac", bold=True).pack(anchor="w", pady=(0, 8))
        else:
            self._label(self.content, "MT5 още не е свързан. Върни се към етап 2.", color="#ff9696").pack(anchor="w")
        self._label(self.content, "Преглед на минималните обеми, котировките и маржина — без изпращане на сделки.",
                    color="#a4b6c9", wrap=630).pack(anchor="w", pady=(0, 14))
        self._button(self.content, "Провери пазари и сметка (без сделки)", self._diagnose)
        self.report = tk.Text(self.content, height=9, bg="#111b29", fg="#f5f6fa",
                              font=("Consolas", 10), relief="flat", wrap="word")
        self.report.pack(fill="both", expand=True, pady=(4, 5))
        self.report.insert("1.0", self.diagnostic_result or "Натисни бутона за проверка на сметка и инструменти.")
        self.report.configure(state="disabled")
        self.next_button.config(text="Отвори Trading AI")

    def next_step(self):
        if self.step == 0:
            if not valid_terminal_path(self.app.terminal.get()):
                self._refresh_terminal()
                if not valid_terminal_path(self.app.terminal.get()):
                    messagebox.showinfo("Нужен е MT5", "Инсталирай MT5 или избери terminal64.exe, после продължи.", parent=self)
                    return
            self.show_step(1)
        elif self.step == 1:
            if self.app.connected:
                self.show_step(2)
            else:
                self.app._connect()
        else:
            if not self.app.connected:
                messagebox.showwarning("MT5", "Първо свържи брокерската сметка.", parent=self)
                return
            if not self.app.demo:
                messagebox.showinfo("REAL е заключен", "Реалната сметка може само да се наблюдава. Демо търговията се тества отделно.", parent=self)
            self._close()

    def prev_step(self):
        self.show_step(self.step - 1)

    def on_connected(self):
        if self.winfo_exists():
            self.show_step(2)

    def _diagnose(self):
        if not self.app.connected:
            messagebox.showwarning("MT5", "Няма свързана сметка.", parent=self)
            return
        symbols = [x.strip() for x in self.app.symbols.get().split(",") if x.strip()][:4]
        self.app.worker.send("diagnose", symbols=symbols)
        self.report.configure(state="normal")
        self.report.delete("1.0", "end")
        self.report.insert("1.0", "Проверявам брокерските параметри…")
        self.report.configure(state="disabled")

    def on_diagnostics(self, result: dict):
        if not self.winfo_exists() or self.step != 2:
            return
        lines = ["Сметка: " + result.get("account_type", "UNKNOWN"),
                 "Валута: " + result.get("currency", "—"),
                 "Тестов капитал: максимум €100", ""]
        for sym in result.get("symbols", []):
            lines.append(sym["symbol"] + " — " + sym.get("state", "НЕИЗВЕСТНО"))
            if "min_lot" in sym:
                lines.append("  Мин. лот: {}  |  Спред: {}  |  BUY маржин: {}".format(
                    sym.get("min_lot", "—"), sym.get("spread", "—"), sym.get("margin_eur", "—")))
        lines.extend(["", "Тази проверка не отваря сделки и не доказва готовност за реални пари."])
        self.diagnostic_result = "\n".join(lines)
        self.report.configure(state="normal")
        self.report.delete("1.0", "end")
        self.report.insert("1.0", self.diagnostic_result)
        self.report.configure(state="disabled")

    def _close(self):
        self.app.wizard = None
        self.destroy()
