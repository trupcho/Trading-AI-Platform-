"""TauricResearch TradingAgents v0.7.1 integration for demo-only research gating.

Broker data execution remains in core.py; TradingAgents sees external research
proxies and never obtains broker login, passwords or order_send access.
"""
from __future__ import annotations
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Any
import json
import re
import time
from urllib.parse import urlparse
import webbrowser

# Research proxy != broker symbol. Exact whitelist is intentional.
RESEARCH_SYMBOLS = {
    'XAUUSD': 'GC=F', 'NAS100': '^NDX', 'EURUSD': 'EURUSD=X',
    'GBPUSD': 'GBPUSD=X', 'BTCUSD': 'BTC-USD',
}
MAX_REPORT_AGE_SECONDS = 21600  # Upstream is a daily research model, not tick signal.
AUTH_HOSTS = {'auth.openai.com', 'chatgpt.com', 'localhost', '127.0.0.1'}


def parse_action(value: Any) -> str:
    """Explicit machine action only, never a narrative or inferred sentiment."""
    if isinstance(value, dict):
        if set(value) != {'action'}:
            return 'UNRESOLVED'
        value = value['action']
    if not isinstance(value, str):
        return 'UNRESOLVED'
    raw = value.strip()
    if raw.upper() in {'BUY', 'SELL', 'HOLD'}:
        return raw.upper()
    try:
        obj = json.loads(raw)
    except (ValueError, TypeError):
        return 'UNRESOLVED'
    return parse_action(obj) if isinstance(obj, dict) else 'UNRESOLVED'


def ai_permission(symbol: str, direction: str, folder: Path,
                  *, now: float | None = None, today: str | None = None) -> bool:
    if symbol not in RESEARCH_SYMBOLS or direction not in {'BUY', 'SELL'}:
        return False
    now = time.time() if now is None else now
    today = today or datetime.fromtimestamp(now, timezone.utc).date().isoformat()
    try:
        report = json.loads((folder / f'{symbol}_{today}.json').read_text(encoding='utf8'))
        issued = float(report.get('generated_at_epoch', 0))
    except (OSError, ValueError, TypeError, json.JSONDecodeError, UnicodeError):
        return False
    return (report.get('market') == symbol and
            report.get('proxy') == RESEARCH_SYMBOLS[symbol] and
            report.get('date_utc') == today and
            report.get('action') == direction and
            report.get('approved') is False and
            report.get('provider') == 'chatgpt' and
            0 <= now - issued <= MAX_REPORT_AGE_SECONDS)


def tradingagents_config():
    """Bundled upstream framework with a ChatGPT-plan provider preset.

    No OpenAI API key, broker secret, or user-specific credential is embedded.
    User must authorize ChatGPT OAuth once in the official browser flow.
    """
    from tradingagents.default_config import DEFAULT_CONFIG
    cfg = DEFAULT_CONFIG.copy()
    cfg['llm_provider'] = 'chatgpt'
    cfg['quick_think_provider'] = 'chatgpt'
    cfg['deep_think_provider'] = 'chatgpt'
    cfg['max_debate_rounds'] = 1
    cfg['max_risk_discuss_rounds'] = 1
    cfg['output_language'] = 'English'
    return cfg


def tradingagents_installed() -> bool:
    try:
        from tradingagents.graph.trading_graph import TradingAgentsGraph  # noqa: F401
        from tradingagents.llm_clients import chatgpt_auth  # noqa: F401
        return True
    except (ImportError, ModuleNotFoundError):
        return False


def _trusted_auth_url(message: str) -> str | None:
    for token in re.findall(r'https?://[^\s<>]+', message):
        url = token.rstrip(').,;\'"')
        parsed = urlparse(url)
        if parsed.hostname in AUTH_HOSTS:
            return url
    return None


def sign_in_chatgpt(notify: Callable[[str], None],
                    open_url: Callable[[str], Any] | None = None) -> str:
    """Official upstream subscription OAuth; no plaintext tokens in app logs."""
    from tradingagents.llm_clients import chatgpt_auth
    opened: set[str] = set()
    def on_line(message: str):
        url = _trusted_auth_url(str(message))
        if url and url not in opened:
            opened.add(url)
            (open_url or webbrowser.open)(url)
            notify('Отворих браузъра за потвърждение на ChatGPT. Продължи там.')
        else:
            notify('Изчаквам потвърждение в ChatGPT…')
    email = chatgpt_auth.sign_in(say=on_line)
    if not email:
        raise RuntimeError('ChatGPT login did not return a signed-in account')
    return 'ChatGPT е свързан успешно.'


def research(symbol: str, folder: Path, *, graph_factory=None,
             now: float | None = None) -> dict:
    """Run the *actual* TradingAgents graph, with bounded output and failed-closed action.

    A research BUY/SELL is a direction veto for a separate broker-derived M5
    strategy, not a confirmed intraday edge nor an executable order.
    """
    if symbol not in RESEARCH_SYMBOLS:
        raise ValueError(f'Няма проверено research съответствие за символа {symbol}')
    from tradingagents.graph.trading_graph import TradingAgentsGraph
    now = time.time() if now is None else now
    day = datetime.fromtimestamp(now, timezone.utc).date().isoformat()
    cfg = tradingagents_config()
    factory = graph_factory or TradingAgentsGraph
    graph = factory(debug=False, config=cfg)
    _state, decision = graph.propagate(RESEARCH_SYMBOLS[symbol], day)
    action = parse_action(decision)
    if action == 'UNRESOLVED':
        action = parse_action(str(decision))
    record = {
        'market': symbol,
        'proxy': RESEARCH_SYMBOLS[symbol],
        'date_utc': day,
        'generated_at_epoch': now,
        'provider': 'chatgpt',
        'action': action,
        'approved': False,
        'model_warning': 'Research-only proxy; NOT executable MT5 CFD prices; AI cannot bypass risk checks',
        'raw_decision': str(decision)[:2500],
    }
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / f'{symbol}_{day}.json'
    temp = target.with_suffix('.tmp')
    temp.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding='utf-8')
    temp.replace(target)
    return record
