@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if errorlevel 1 (
  echo Python launcher was not found.
  echo Install 64-bit Python 3.11 or newer from https://www.python.org/downloads/windows/
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  py -3 -m venv .venv
  if errorlevel 1 (echo Python environment setup failed.& pause & exit /b 1)
)
".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install -r requirements-windows.txt
if errorlevel 1 (echo MetaTrader5 installation failed. Check that Windows and Python are 64-bit.& pause & exit /b 1)
".venv\Scripts\python.exe" run_desktop.py
if errorlevel 1 (echo Trading AI exited with an error.& pause & exit /b 1)
