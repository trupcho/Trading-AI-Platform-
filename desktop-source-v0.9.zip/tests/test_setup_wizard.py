"""Tests for onboarding helper and read-only broker diagnostics."""
from pathlib import Path
from types import SimpleNamespace as S
from tempfile import TemporaryDirectory
from unittest import TestCase
from unittest.mock import patch
import time

from trading_ai_desktop.first_run import find_mt5_terminals, valid_terminal_path
from trading_ai_desktop.core import Connection, TradingWorker
from test_desktop_core import DummyMT5


class SetupWizardTests(TestCase):
    def test_finds_valid_terminal_without_launching_it(self):
        with TemporaryDirectory() as tmp:
            folder = Path(tmp) / 'Broker MT5'
            folder.mkdir()
            executable = folder / 'terminal64.exe'
            executable.write_bytes(b'fake exe only for discovery test')
            result = find_mt5_terminals({'PROGRAMFILES':tmp})
            self.assertEqual(result, [str(executable)])
            self.assertTrue(valid_terminal_path(str(executable)))

    def test_invalid_executable_rejected(self):
        with TemporaryDirectory() as tmp:
            executable=Path(tmp) / 'some-other.exe'
            executable.write_text('not mt5')
            self.assertFalse(valid_terminal_path(str(executable)))

    def test_empty_search_does_not_crash(self):
        self.assertEqual(find_mt5_terminals({'PROGRAMFILES':'Z:/not-found'}), [])

    def test_diagnostics_does_not_send_orders(self):
        with TemporaryDirectory() as tmp:
            events=[]
            mt=DummyMT5()
            worker=TradingWorker(lambda kind,data:events.append((kind,data)),mt5=mt,data_dir=Path(tmp))
            worker._connect(Connection(6001,'Broker-Demo','placeholder'))
            worker._diagnose(['XAUUSD'])
            result=[d for kind,d in events if kind=='diagnostics'][-1]
            self.assertEqual(result['account_type'], 'DEMO')
            self.assertEqual(result['symbols'][0]['min_lot'], '0.0001')
            self.assertEqual(mt.orders_sent,0)

    def test_diagnostics_blocks_changed_account(self):
        with TemporaryDirectory() as tmp:
            events=[]
            mt=DummyMT5()
            worker=TradingWorker(lambda kind,data:events.append((kind,data)),mt5=mt,data_dir=Path(tmp))
            worker._connect(Connection(6001,'Broker-Demo','placeholder'))
            mt.account.login=7
            worker._diagnose(['XAUUSD'])
            result=[d for kind,d in events if kind=='diagnostics'][-1]
            self.assertEqual(result['account_type'],'DISCONNECTED')
            self.assertEqual(mt.orders_sent,0)

    def test_diagnostics_handles_stale_quote(self):
        with TemporaryDirectory() as tmp:
            events=[]
            mt=DummyMT5()
            worker=TradingWorker(lambda kind,data:events.append((kind,data)),mt5=mt,data_dir=Path(tmp))
            worker._connect(Connection(6001,'Broker-Demo','placeholder'))
            mt.tick.time=int(time.time())-5000
            worker._diagnose(['XAUUSD'])
            result=[d for kind,d in events if kind=='diagnostics'][-1]
            self.assertIn('стара',result['symbols'][0]['state'])
            self.assertEqual(mt.orders_sent,0)

    def test_real_account_is_read_only_in_wizard(self):
        with TemporaryDirectory() as tmp:
            events=[]
            mt=DummyMT5(demo=False)
            worker=TradingWorker(lambda kind,data:events.append((kind,data)),mt5=mt,data_dir=Path(tmp))
            worker._connect(Connection(6001,'Broker-Demo','placeholder'))
            worker._diagnose(['XAUUSD'])
            result=[d for kind,d in events if kind=='diagnostics'][-1]
            self.assertEqual(result['account_type'],'REAL / MONITOR ONLY')
            self.assertEqual(mt.orders_sent,0)

if __name__ == '__main__':
    import unittest
    unittest.main()
