import tempfile
import unittest
from pathlib import Path
from trading_ai_desktop.core import AuditStore, CAPITAL_CAP, MAX_DAY_LOSS_PCT

class PersistentSafetyTests(unittest.TestCase):
    def test_recent_submission_durable(self):
        with tempfile.TemporaryDirectory() as d:
            one=AuditStore(Path(d))
            self.assertFalse(one.recent_submission('1'))
            self.assertTrue(one.reserve_order('some-key','1'))
            one.finish('some-key', 'DONE', 'broker ok')
            another=AuditStore(Path(d))
            self.assertTrue(another.recent_submission('1'))
            self.assertFalse(another.recent_submission('different'))

    def test_big_demo_balance_daily_cap_is_one_euro(self):
        base=100000
        expected_stop = base-min(base,float(CAPITAL_CAP))*float(MAX_DAY_LOSS_PCT)
        self.assertEqual(expected_stop,99999.0)

if __name__=='__main__': unittest.main()
