"""Deterministic tests of upstream ChatGPT integration without network or credentials."""
import json
import sys
import time
import tempfile
import unittest
from pathlib import Path
from types import ModuleType
from unittest.mock import patch

from trading_ai_desktop.ai import (parse_action, ai_permission, research,
                                    tradingagents_config, sign_in_chatgpt,
                                    _trusted_auth_url, RESEARCH_SYMBOLS)

class TradingAgentsTests(unittest.TestCase):
    def test_strict_text(self):
        self.assertEqual(parse_action('BUY'), 'BUY')
        self.assertEqual(parse_action('{"action": "SELL"}'), 'SELL')
        self.assertEqual(parse_action('Buying is recommended'), 'UNRESOLVED')
        self.assertEqual(parse_action('{"action":"BUY", "lots":100}'), 'UNRESOLVED')
        self.assertEqual(parse_action(None), 'UNRESOLVED')

    def test_oauth_only_trusted_hosts(self):
        self.assertEqual(_trusted_auth_url('Open https://auth.openai.com/login'), 'https://auth.openai.com/login')
        self.assertIsNone(_trusted_auth_url('https://evil.site/collect'))

    def test_report_timestamp_and_proxy_blocks(self):
        from datetime import datetime, timezone
        now=time.time();today=datetime.fromtimestamp(now, timezone.utc).date().isoformat()
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/f'XAUUSD_{today}.json'
            base={'market':'XAUUSD','proxy':'GC=F','date_utc':today,
                  'provider':'chatgpt','generated_at_epoch':now,
                  'action':'BUY','approved':False}
            p.write_text(json.dumps(base))
            self.assertTrue(ai_permission('XAUUSD','BUY',Path(d),now=now))
            self.assertFalse(ai_permission('XAUUSD','SELL',Path(d),now=now))
            base['generated_at_epoch']=now-21601;p.write_text(json.dumps(base))
            self.assertFalse(ai_permission('XAUUSD','BUY',Path(d),now=now))
            base['generated_at_epoch']=now;base['proxy']='XAUUSD';p.write_text(json.dumps(base))
            self.assertFalse(ai_permission('XAUUSD','BUY',Path(d),now=now))
            base['proxy']='GC=F';base['provider']='fake';p.write_text(json.dumps(base))
            self.assertFalse(ai_permission('XAUUSD','BUY',Path(d),now=now))

    def test_tradingagents_research_called_and_never_executes(self):
        from datetime import datetime, timezone
        cfg=ModuleType('tradingagents.default_config')
        cfg.DEFAULT_CONFIG={'llm_provider':'openai','quick_think_llm':'a',
                            'deep_think_llm':'b','max_debate_rounds':2}
        graphmod=ModuleType('tradingagents.graph.trading_graph')
        calls=[]
        class FakeGraph:
            def __init__(self,**kwargs):calls.append(('init',kwargs))
            def propagate(self,symbol,day):calls.append(('propagate',symbol,day));return {},'{"action":"BUY"}'
        graphmod.TradingAgentsGraph=FakeGraph
        with patch.dict(sys.modules, {'tradingagents':ModuleType('tradingagents'),
                                      'tradingagents.default_config':cfg,
                                      'tradingagents.graph':ModuleType('tradingagents.graph'),
                                      'tradingagents.graph.trading_graph':graphmod}):
            with tempfile.TemporaryDirectory() as d:
                report=research('XAUUSD',Path(d),now=time.time())
                self.assertEqual(report['action'],'BUY')
                self.assertFalse(report['approved'])
                self.assertEqual(calls[0][1]['config']['llm_provider'],'chatgpt')
                self.assertEqual(calls[1][1],RESEARCH_SYMBOLS['XAUUSD'])
                self.assertTrue(ai_permission('XAUUSD','BUY',Path(d)))

    def test_chatgpt_login_calls_official_provider(self):
        auth=ModuleType('tradingagents.llm_clients.chatgpt_auth')
        auth.sign_in=lambda say: (say('Visit https://auth.openai.com/authorize?client_id=123'), 'user@local.test')[1]
        llm=ModuleType('tradingagents.llm_clients');llm.chatgpt_auth=auth
        seen=[];messages=[]
        with patch.dict(sys.modules,{'tradingagents':ModuleType('tradingagents'),
                                     'tradingagents.llm_clients':llm,
                                     'tradingagents.llm_clients.chatgpt_auth':auth}):
            output=sign_in_chatgpt(messages.append,seen.append)
        self.assertIn('свързан',output)
        self.assertEqual(len(seen),1)
        self.assertTrue(seen[0].startswith('https://auth.openai.com/'))
        self.assertFalse(any('client_id=' in message for message in messages))

    def test_reject_unknown_ticker(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(ValueError):research('UNKNOWN',Path(d))

if __name__=='__main__':unittest.main()
