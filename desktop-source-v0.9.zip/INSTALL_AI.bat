@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (echo First run INSTALL_AND_RUN.bat.& pause & exit /b 1)
where git >nul 2>&1
if errorlevel 1 (echo Install Git for Windows first: https://git-scm.com/download/win& pause & exit /b 1)
".venv\Scripts\python.exe" -m pip install "git+https://github.com/TauricResearch/TradingAgents.git"
if errorlevel 1 (echo TradingAgents installation failed.& pause & exit /b 1)
echo TradingAgents installed. Choose a supported provider and sign in.
echo If using ChatGPT plan, use the provider OAuth shown by the TradingAgents CLI.
echo Other options: local Ollama, or LLM API billing.
echo To use ChatGPT account login, run the following in a Command Prompt:
echo .venv\Scripts\tradingagents.exe login chatgpt
echo Alternatively configure Ollama or your API provider per the upstream docs.
pause
