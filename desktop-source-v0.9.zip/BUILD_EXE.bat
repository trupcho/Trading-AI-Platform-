@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (echo Run INSTALL_AND_RUN.bat first.& pause & exit /b 1)
".venv\Scripts\python.exe" -m pip install pyinstaller
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --onefile --windowed --name "TradingAI-Desktop" --hidden-import MetaTrader5 run_desktop.py
if errorlevel 1 (echo EXE build failed.& pause & exit /b 1)
echo EXE available at dist\TradingAI-Desktop.exe
pause
