from solana_desk.server import main
if __name__ == '__main__':
    main()
