import datetime as dt
import json
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch
from solana_desk.core import Analyst, Desk, DexScreener, Filter, GMGN, MissingEvidence, PaperBroker, Risk, Scout, Settings, Journal, number, safe_pct
from solana_desk.server import make_handler, html_file
from http.server import ThreadingHTTPServer
import http.client
import time

MINT='9'*44
NOW_MS=1_800_000_000_000

def pair(**kw):
    d={"chainId":"solana","pairAddress":"pool","baseToken":{"address":MINT,"symbol":"TEST"},
       "priceUsd":"0.01","pairCreatedAt":NOW_MS-90*60000,"marketCap":1_000_000,
       "liquidity":{"usd":750_000},"txns":{"h1":{"buys":800,"sells":100}},"priceChange":{"h1":45}}
    d.update(kw)
    return d

def evidence(**overrides):
    sec={"renounced_mint":True,"renounced_freeze_account":True,"top_10_holder_rate":0.15,
         "dev_holder_rate":0.02,"bundled_launch_rate":0.05,"creator_prior_rugs":False}
    info={"unique_buyers_1h":150,"holder_growth_1h_pct":25,"wallet_tags_stat":{"smart_wallets":20}}
    pool={"lp_locked":True}
    e=dict(security=sec,info=info,pool=pool)
    e.update(overrides)
    return e

class FakeMarket:
    def __init__(self,pairs):self.pairs=pairs
    def discover(self):return list(self.pairs)
    def token_pair(self,mint):return self.pairs[0] if self.pairs else None

class FakeGMGN:
    executable='fake_verified'
    def __init__(self,e=None):self.e=e or evidence()
    def evidence(self,mint):return self.e

class Tests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.s=Settings()
    def tearDown(self):
        Journal.close_test_handles()
        self.temp.cleanup()

    def test_scout_accepts_valid_pair(self):
        bad,m=Scout(self.s).assess(pair(),now_ms=NOW_MS)
        self.assertEqual(bad,[]);self.assertEqual(m['mcap'],1_000_000)
    def test_scout_age_under_30_rejected(self):
        reasons,_=Scout(self.s).assess(pair(pairCreatedAt=NOW_MS-20*60000),now_ms=NOW_MS)
        self.assertTrue(reasons)
    def test_scout_age_over_72h_rejected(self):
        reasons,_=Scout(self.s).assess(pair(pairCreatedAt=NOW_MS-80*3600000),now_ms=NOW_MS)
        self.assertTrue(reasons)
    def test_scout_negative_price_rejected(self):
        reasons,_=Scout(self.s).assess(pair(priceUsd='-3'),now_ms=NOW_MS)
        self.assertTrue(reasons)
    def test_scout_zero_liquidity_rejected(self):
        reasons,_=Scout(self.s).assess(pair(liquidity={'usd':0}),now_ms=NOW_MS)
        self.assertTrue(reasons)
    def test_80_pct_chase_rejected(self):
        p=pair(priceChange={'h1':90});_,m=Scout(self.s).assess(p,now_ms=NOW_MS)
        self.assertTrue(any('80%' in x for x in Filter(self.s).assess(p,m,evidence())))
    def test_liq_mcap_under_25_rejected(self):
        p=pair(liquidity={'usd':100_000});_,m=Scout(self.s).assess(p,now_ms=NOW_MS)
        self.assertTrue(Filter(self.s).assess(p,m,evidence()))
    def test_unknown_security_rejected(self):
        _,m=Scout(self.s).assess(pair(),now_ms=NOW_MS)
        self.assertTrue(Filter(self.s).assess(pair(),m,None))
    def test_bad_mint_rejected(self):
        e=evidence();e['security']['renounced_mint']=False
        _,m=Scout(self.s).assess(pair(),now_ms=NOW_MS)
        self.assertTrue(any('mint' in x for x in Filter(self.s).assess(pair(),m,e)))
    def test_missing_lp_proof_rejected(self):
        e=evidence();e['pool']={}
        _,m=Scout(self.s).assess(pair(),now_ms=NOW_MS)
        self.assertTrue(any('LP' in x for x in Filter(self.s).assess(pair(),m,e)))
    def test_dev_pct_over_three_rejected(self):
        e=evidence();e['security']['dev_holder_rate']=0.05
        _,m=Scout(self.s).assess(pair(),now_ms=NOW_MS)
        self.assertTrue(any('dev' in x for x in Filter(self.s).assess(pair(),m,e)))
    def test_bundle_pct_over_ten_rejected(self):
        e=evidence();e['security']['bundled_launch_rate']=0.11
        _,m=Scout(self.s).assess(pair(),now_ms=NOW_MS)
        self.assertTrue(any('bundled' in x for x in Filter(self.s).assess(pair(),m,e)))
    def test_unknown_creator_history_rejected(self):
        e=evidence();del e['security']['creator_prior_rugs']
        _,m=Scout(self.s).assess(pair(),now_ms=NOW_MS)
        self.assertTrue(any('dev rugs' in x for x in Filter(self.s).assess(pair(),m,e)))
    def test_safe_filter_passes(self):
        _,m=Scout(self.s).assess(pair(),now_ms=NOW_MS)
        self.assertEqual(Filter(self.s).assess(pair(),m,evidence()),[])
    def test_full_score_components(self):
        _,m=Scout(self.s).assess(pair(),now_ms=NOW_MS)
        score,components=Analyst(self.s).assess(pair(),m,evidence())
        self.assertGreaterEqual(score,70);self.assertEqual(len(components),6)
    def test_unknown_unique_buyers_rejected(self):
        e=evidence();del e['info']['unique_buyers_1h']
        _,m=Scout(self.s).assess(pair(),now_ms=NOW_MS)
        with self.assertRaises(MissingEvidence):Analyst(self.s).assess(pair(),m,e)
    def test_scoring_under_70_does_not_pass(self):
        e=evidence(info={'unique_buyers_1h':0,'holder_growth_1h_pct':0,'wallet_tags_stat':{'smart_wallets':0}})
        p=pair(priceChange={'h1':-10},txns={'h1':{'buys':0,'sells':999}})
        _,m=Scout(self.s).assess(p,now_ms=NOW_MS)
        score,_=Analyst(self.s).assess(p,m,e)
        self.assertLess(score,70)
    def test_eight_percent_position_cap(self):
        j=Journal(Path(self.temp.name)/'test.db');b=PaperBroker(self.s,j)
        self.assertTrue(b.buy(MINT,'TEST',1,90))
        self.assertAlmostEqual(b.positions[MINT]['entry_cost'],8,places=4)
    def test_paper_stop_causes_exit(self):
        j=Journal(Path(self.temp.name)/'test.db');b=PaperBroker(self.s,j)
        b.buy(MINT,'TEST',1,90);b.mark(MINT,.90)
        self.assertEqual(len(b.positions),0)
        self.assertLess(b.realized,0)
    def test_trail_only_after_plus_twelve(self):
        j=Journal(Path(self.temp.name)/'test.db');b=PaperBroker(self.s,j)
        b.buy(MINT,'TEST',1,90);b.mark(MINT,1.08)
        self.assertFalse(b.positions[MINT]['trailing'])
        b.mark(MINT,1.20)
        self.assertTrue(b.positions[MINT]['trailing'])
        b.mark(MINT,1.10)
        self.assertEqual(b.positions,{})
    def test_stop_not_guaranteed_price(self):
        j=Journal(Path(self.temp.name)/'test.db');b=PaperBroker(self.s,j)
        b.buy(MINT,'TEST',1,90);b.mark(MINT,0.5)
        self.assertLess(b.realized,-3)
    def test_bad_gmgn_address_fails_closed(self):
        with self.assertRaises(MissingEvidence):GMGN('gmgn-cli').evidence('not-an-address')
    def test_no_gmgn_no_paper_trades(self):
        d=Desk(Path(self.temp.name),market=FakeMarket([pair()]))
        d.running=True
        with patch('solana_desk.core.time.time',return_value=NOW_MS/1000):d.run_cycle()
        self.assertEqual(d.paper.positions,{})
        self.assertEqual(d.killed,1)
        self.assertTrue(any(x['kind']=='KILL' for x in d.j.events()))
    def test_full_verified_handoff_paper_buy(self):
        d=Desk(Path(self.temp.name),market=FakeMarket([pair()]),gmgn=FakeGMGN())
        d.running=True
        with patch('solana_desk.core.time.time',return_value=NOW_MS/1000):d.run_cycle()
        self.assertEqual(len(d.paper.positions),1)
        self.assertEqual(d.qualified,1)
        self.assertTrue(any(x['kind']=='PAPER_BUY' for x in d.j.events()))
    def test_no_duplicate_paper_buy(self):
        d=Desk(Path(self.temp.name),market=FakeMarket([pair()]),gmgn=FakeGMGN())
        d.running=True
        with patch('solana_desk.core.time.time',return_value=NOW_MS/1000):
            d.run_cycle();d.run_cycle()
        self.assertEqual(d.paper.trades,1)
    def test_live_execution_not_present(self):
        d=Desk(Path(self.temp.name))
        self.assertEqual(d.mode,'PAPER_ONLY')
        self.assertFalse(hasattr(d.paper,'send_transaction'))
        self.assertFalse(hasattr(d.paper,'sign'))
    def test_host_headers_fail_closed(self):
        d=Desk(Path(self.temp.name))
        H=make_handler(d,'test-token')
        server=ThreadingHTTPServer(('127.0.0.1',8777),H)
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        try:
            c=http.client.HTTPConnection('127.0.0.1',8777,timeout=3)
            c.request('GET','/api/status',headers={'Host':'localhost:8777','X-Paper-Token':'test-token'})
            r=c.getresponse();self.assertEqual(r.status,403);r.read();c.close()
            c=http.client.HTTPConnection('127.0.0.1',8777,timeout=3)
            c.request('GET','/api/status',headers={'Host':'127.0.0.1:8777','X-Paper-Token':'bad'})
            r=c.getresponse();self.assertEqual(r.status,403);r.read();c.close()
        finally:server.shutdown();server.server_close();thread.join()
    def test_html_selftest(self):
        self.assertTrue(html_file().exists())
        self.assertIn('REPLACE_LOCAL_TOKEN',html_file().read_text('utf8'))

if __name__=='__main__': unittest.main()

class PersistenceTests(unittest.TestCase):
    def test_paper_survives_restart(self):
        with tempfile.TemporaryDirectory() as t:
            path=Path(t)/'p.db'
            s=Settings()
            a=PaperBroker(s,Journal(path))
            a.buy(MINT,'TEST',1,90)
            a.mark(MINT,1.20)
            b=PaperBroker(s,Journal(path))
            self.assertEqual(set(b.positions),{MINT})
            self.assertTrue(b.positions[MINT]['trailing'])
            self.assertAlmostEqual(a.cash,b.cash)
            Journal.close_test_handles()
