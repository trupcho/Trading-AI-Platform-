"""Trading AI Solana Paper Desk (standalone; not the MT5 trading app)."""
