"""Local-only HTTP dashboard. No browser/cloud credentials are required."""
from __future__ import annotations
import argparse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import secrets
import sys
import threading
import webbrowser

from .core import Desk, Settings
PORT=8777


def html_file():
    root=Path(getattr(sys,'_MEIPASS', Path(__file__).resolve().parent))
    candidate=root/'solana_desk'/'index.html'
    return candidate if candidate.exists() else Path(__file__).resolve().parent/'index.html'


def make_handler(desk: Desk, secret: str):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, fmt, *args):
            return
        def send(self, code, value, mime='application/json; charset=utf-8'):
            raw=value.encode('utf-8') if isinstance(value,str) else json.dumps(value,ensure_ascii=False).encode('utf-8')
            self.send_response(code)
            self.send_header('Content-Type',mime)
            self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Referrer-Policy','no-referrer')
            self.send_header('Cache-Control','no-store')
            self.send_header('Content-Security-Policy', "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; object-src 'none'; frame-ancestors 'none'")
            self.send_header('Content-Length',str(len(raw)))
            self.end_headers();self.wfile.write(raw)
        def valid_host(self):
            return self.headers.get('Host','') == f'127.0.0.1:{PORT}'
        def authorized(self):
            return self.valid_host() and secrets.compare_digest(self.headers.get('X-Paper-Token',''),secret)
        def do_GET(self):
            if not self.valid_host():return self.send(403,{'error':'local-only host'})
            if self.path=='/':
                raw=html_file().read_text(encoding='utf-8')
                raw=raw.replace('REPLACE_LOCAL_TOKEN',secret)
                return self.send(200,raw,'text/html; charset=utf-8')
            if self.path=='/api/status':
                if not self.authorized():return self.send(403,{'error':'unauthorized'})
                return self.send(200,desk.status())
            self.send(404,{'error':'not found'})
        def do_POST(self):
            if not self.authorized():return self.send(403,{'error':'unauthorized'})
            if self.headers.get('Origin') not in (None, f'http://127.0.0.1:{PORT}'):
                return self.send(403,{'error':'invalid origin'})
            if self.headers.get('Content-Length') not in (None,'0'):
                return self.send(400,{'error':'body not accepted'})
            if self.path=='/api/start':return self.send(200,{'started':desk.start()})
            if self.path=='/api/stop':
                desk.stop();return self.send(200,{'stopped':True})
            self.send(404,{'error':'not found'})
    return Handler


def main():
    parser=argparse.ArgumentParser(description='Solana multi-agent PAPER trading desk')
    parser.add_argument('--data-dir',default=str(Path.home()/'TradingAI-SolanaPaper'))
    parser.add_argument('--selftest',action='store_true')
    args=parser.parse_args()
    if args.selftest:
        assert html_file().exists()
        assert 'REPLACE_LOCAL_TOKEN' in html_file().read_text('utf-8')
        print('paper-only UI selftest OK');return
    desk=Desk(Path(args.data_dir))
    try:
        server=ThreadingHTTPServer(('127.0.0.1',PORT),make_handler(desk,secrets.token_urlsafe(30)))
    except OSError as exc:
        print(f'Cannot bind local port {PORT}: {exc}. Close previous desk instance and retry.')
        raise SystemExit(1)
    print(f'Solana PAPER DESK on http://127.0.0.1:{PORT} — no live swaps, no wallet signing')
    threading.Timer(1.0,lambda:webbrowser.open(f'http://127.0.0.1:{PORT}')).start()
    try:server.serve_forever(poll_interval=0.25)
    finally:desk.stop();server.server_close()

if __name__=='__main__':main()
