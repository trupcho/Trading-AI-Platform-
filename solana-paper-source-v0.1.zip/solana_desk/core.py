"""Six-agent paper-only Solana memecoin desk. Never signs or broadcasts transactions."""
from __future__ import annotations
import dataclasses
import datetime as dt
import json
import math
import os
from pathlib import Path
import sqlite3
import subprocess
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import weakref
from collections import deque

UTC = dt.timezone.utc


def timestamp() -> str:
    return dt.datetime.now(UTC).isoformat(timespec='seconds')


def number(value, default=None):
    try:
        n = float(value)
        return n if math.isfinite(n) else default
    except (ValueError, TypeError, OverflowError):
        return default


def safe_pct(value):
    n = number(value)
    if n is None or n < 0:
        return None
    return n / 100 if n > 1 else n


def need(value, name):
    if value is None:
        raise MissingEvidence(f'{name}: няма достоверни данни')
    return value


class MissingEvidence(Exception):
    pass


@dataclasses.dataclass(frozen=True)
class Settings:
    initial_balance_usd: float = 100.0
    min_age_minutes: int = 30
    max_age_hours: int = 72
    min_mcap_usd: float = 300_000.0
    max_mcap_usd: float = 20_000_000.0
    min_liquidity_ratio: float = 0.25
    max_top10_pct: float = 0.25
    max_dev_pct: float = 0.03
    max_bundle_pct: float = 0.10
    max_hourly_gain_pct: float = 80.0
    min_score: int = 70
    max_alloc_pct: float = 0.08
    stop_loss_pct: float = 0.06
    trail_trigger_pct: float = 0.12
    trail_distance_pct: float = 0.06
    max_positions: int = 3
    daily_loss_limit_pct: float = 0.03
    scan_seconds: int = 90
    stale_seconds: int = 180
    # Illustrative costs for PAPER only; no prediction of actual execution costs.
    paper_slippage_pct: float = 0.01
    paper_fee_pct: float = 0.005


class Journal:
    _instances = weakref.WeakSet()

    @classmethod
    def close_test_handles(cls):
        """Close SQLite handles so Windows can remove temporary test directories."""
        for journal in list(cls._instances):
            journal.close()

    def close(self):
        with self.lock:
            try:self.db.close()
            except sqlite3.ProgrammingError:pass

    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(path, check_same_thread=False, timeout=15)
        self.lock = threading.RLock()
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY, ts TEXT, agent TEXT, kind TEXT, mint TEXT, symbol TEXT, detail TEXT)')
        self.db.execute('CREATE TABLE IF NOT EXISTS equity (id INTEGER PRIMARY KEY, ts TEXT, usd REAL)')
        self.db.execute('CREATE TABLE IF NOT EXISTS paper_state (id INTEGER PRIMARY KEY CHECK(id=1), value TEXT NOT NULL)')
        self.db.commit()
        self._instances.add(self)

    def log(self, agent, kind, detail, mint='', symbol=''):
        # Never put credentials, request payloads, URLs with tokens or private keys in logs.
        with self.lock:
            self.db.execute('INSERT INTO events (ts,agent,kind,mint,symbol,detail) VALUES (?,?,?,?,?,?)',
                            (timestamp(), agent, kind, mint[:64], symbol[:24], str(detail)[:480]))
            self.db.commit()

    def record_equity(self, value):
        with self.lock:
            self.db.execute('INSERT INTO equity(ts,usd) VALUES (?,?)', (timestamp(), round(value, 6)))
            self.db.commit()

    def save_state(self, data):
        with self.lock:
            self.db.execute('INSERT OR REPLACE INTO paper_state (id,value) VALUES (1,?)', (json.dumps(data, ensure_ascii=False),))
            self.db.commit()

    def load_state(self):
        with self.lock:
            row = self.db.execute('SELECT value FROM paper_state WHERE id=1').fetchone()
        return json.loads(row[0]) if row else None

    def events(self, limit=100):
        with self.lock:
            rows = self.db.execute('SELECT ts,agent,kind,mint,symbol,detail FROM events ORDER BY id DESC LIMIT ?', (min(limit, 300),)).fetchall()
        return [dict(zip(('ts','agent','kind','mint','symbol','detail'), row)) for row in rows]

    def equity(self, limit=150):
        with self.lock:
            rows = self.db.execute('SELECT ts,usd FROM equity ORDER BY id DESC LIMIT ?', (min(limit, 200),)).fetchall()
        return [dict(ts=ts, usd=usd) for ts, usd in reversed(rows)]


class DexScreener:
    ROOT = 'https://api.dexscreener.com'
    def __init__(self):
        self.last_error = None

    def get(self, path):
        request = urllib.request.Request(self.ROOT+path, headers={'User-Agent': 'TradingAI-SolanaPaperDesk/0.1', 'Accept': 'application/json'})
        with urllib.request.urlopen(request, timeout=12) as response:
            data = response.read(2_000_000)
            return json.loads(data)

    def discover(self):
        """Sampling endpoint, NOT every new Solana pair. No false completeness claims."""
        addresses = []
        for path in ('/token-profiles/latest/v1', '/token-boosts/latest/v1'):
            try:
                items = self.get(path)
                addresses.extend(i.get('tokenAddress') for i in items if i.get('chainId') == 'solana' and i.get('tokenAddress'))
            except (urllib.error.URLError, ValueError, KeyError, TypeError) as exc:
                self.last_error = f'{type(exc).__name__} on discovery feed'
        addresses = list(dict.fromkeys(addresses))[:60]
        pairs = []
        for i in range(0, len(addresses), 30):
            batch = ','.join(urllib.parse.quote(a, safe='') for a in addresses[i:i+30])
            try:
                pairs.extend(self.get('/tokens/v1/solana/'+batch))
            except (urllib.error.URLError, ValueError, TypeError) as exc:
                self.last_error = f'{type(exc).__name__} on pair lookup'
        best = {}
        for pair in pairs:
            if pair.get('chainId') != 'solana' or not pair.get('baseToken') or not pair.get('pairAddress'):
                continue
            mint = pair['baseToken'].get('address')
            if not mint:
                continue
            liq = number((pair.get('liquidity') or {}).get('usd'), 0)
            if mint not in best or liq > number((best[mint].get('liquidity') or {}).get('usd'), 0):
                best[mint] = pair
        return list(best.values())

    def token_pair(self, mint):
        pairs = self.get('/token-pairs/v1/solana/'+urllib.parse.quote(mint, safe=''))
        return max((x for x in pairs if x.get('chainId')=='solana'),
                   key=lambda x: number((x.get('liquidity') or {}).get('usd'),0), default=None)


class GMGN:
    """Optional official GMGN CLI. No shell=True, no key in code. Unknown metrics fail closed."""
    def __init__(self, executable=''):
        self.executable = executable or os.getenv('GMGN_CLI_BIN', '').strip()
        self.errors = {}

    def call(self, words, mint):
        if not self.executable:
            raise MissingEvidence('GMGN CLI/API не е конфигуриран')
        if not isinstance(mint, str) or len(mint) < 32 or len(mint) > 44 or not all(c in '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz' for c in mint):
            raise MissingEvidence('невалиден Solana mint адрес')
        command = [self.executable, 'token', words, '--chain', 'sol', '--address', mint, '--raw']
        try:
            p = subprocess.run(command, capture_output=True, text=True, timeout=20,
                               encoding='utf-8', errors='replace', shell=False)
        except (OSError, subprocess.TimeoutExpired):
            raise MissingEvidence('GMGN не отговори навреме') from None
        if p.returncode != 0:
            raise MissingEvidence(f'GMGN {words} query failed (exit {p.returncode})')
        try:
            payload = json.loads(p.stdout)
            if not isinstance(payload, dict) or not payload:
                raise ValueError()
            return payload
        except ValueError:
            raise MissingEvidence('GMGN върна невалиден JSON') from None

    def evidence(self, mint):
        sec = self.call('security', mint)
        info = self.call('info', mint)
        pool = self.call('pool', mint)
        return {'security':sec, 'info':info, 'pool':pool}


class Scout:
    name='SCOUT'
    def __init__(self, settings):self.s=settings
    def assess(self, pair, now_ms=None):
        now_ms = now_ms or int(time.time()*1000)
        minted_at = number(pair.get('pairCreatedAt'))
        mcap = number(pair.get('marketCap'))
        if mcap is None: mcap = number(pair.get('fdv'))  # clearly labeled proxy: may differ from true MC
        liquidity = number((pair.get('liquidity') or {}).get('usd'))
        age_min = (now_ms - minted_at)/60000 if minted_at is not None else None
        reasons=[]
        if age_min is None or age_min < self.s.min_age_minutes or age_min > self.s.max_age_hours*60: reasons.append('възрастта на двойката не е 30m–72h')
        if mcap is None or not self.s.min_mcap_usd <= mcap <= self.s.max_mcap_usd: reasons.append('market cap извън $300k–$20M или неизвестен')
        if liquidity is None or liquidity <= 0:reasons.append('липсва ликвидност')
        price = number(pair.get('priceUsd'))
        if price is None or price <= 0:reasons.append('липсва положителна цена')
        return reasons, {'age_min':age_min,'mcap':mcap,'liquidity':liquidity,'price':price}


class Filter:
    name='FILTER'
    def __init__(self, settings):self.s=settings
    def assess(self, pair, market, evidence):
        reasons=[]
        liq, mcap=market['liquidity'],market['mcap']
        if liq is None or mcap is None or mcap <= 0 or liq/mcap < self.s.min_liquidity_ratio:
            reasons.append('liq/mcap под 25% или неизвестно')
        hour_change = number((pair.get('priceChange') or {}).get('h1'))
        if hour_change is None or hour_change >= self.s.max_hourly_gain_pct:
            reasons.append('1h ръст ≥80% или неизвестен')
        if evidence is None:
            reasons.append('липсва независим on-chain security feed (GMGN)')
            return reasons
        sec, info, pool=evidence['security'],evidence['info'],evidence['pool']
        if sec.get('renounced_mint') is not True: reasons.append('mint authority не е доказано revoked')
        if sec.get('renounced_freeze_account') is not True: reasons.append('freeze authority не е доказано revoked')
        # Do not assume liquidity locked from DEX liquidity alone. Modern CLMM pools need independent proof.
        lp_evidence=pool.get('lp_locked') is True or pool.get('lp_burned') is True or pool.get('liquidity_locked') is True
        if not lp_evidence: reasons.append('LP burn/lock не е потвърден')
        top10=safe_pct(sec.get('top_10_holder_rate'))
        if top10 is None or top10>self.s.max_top10_pct:reasons.append('top10 holders >25% или неизвестно')
        dev=safe_pct(sec.get('dev_holder_rate'))
        if dev is None or dev>self.s.max_dev_pct:reasons.append('dev holdings >3% или неизвестно')
        bundled=safe_pct(sec.get('bundled_launch_rate'))
        if bundled is None or bundled>self.s.max_bundle_pct:reasons.append('bundled launch >10% или неизвестно')
        # `rug_ratio` ≠ creator's rug history: reject unless provable creator wallet history.
        if sec.get('creator_prior_rugs') is not False:reasons.append('липсва потвърдена проверка за минали dev rugs')
        return reasons


class Analyst:
    name='ANALYST'
    def __init__(self, settings):self.s=settings
    def assess(self, pair, market, evidence):
        if evidence is None:
            raise MissingEvidence('липсва on-chain статистика за оценка')
        info=evidence['info']
        stats=(pair.get('txns') or {}).get('h1') or {}
        buys, sells=number(stats.get('buys')),number(stats.get('sells'))
        change=number((pair.get('priceChange') or {}).get('h1'))
        unique=number(info.get('unique_buyers_1h'))
        holders_growth=number(info.get('holder_growth_1h_pct'))
        smart=number((info.get('wallet_tags_stat') or {}).get('smart_wallets'))
        liq=number(market['liquidity']);mcap=number(market['mcap'])
        for key,value in [('1h price change',change),('1h tx buys',buys),('1h tx sells',sells),('unique 1h buyers',unique),('holder growth',holders_growth),('smart wallets',smart),('liq/mcap',liq/mcap if mcap else None)]:
            need(value,key)
        # Transparent capped heuristics, not machine-learned alpha or a claim of win rate.
        components={
            'momentum':round(max(0,min(20,(change+10)/50*20)),1),
            'unique_buyers':round(max(0,min(15,unique/100*15)),1),
            'buy_sell':round(max(0,min(15,(buys/max(1,buys+sells))*15)),1),
            'holder_growth':round(max(0,min(15,holders_growth/20*15)),1),
            'liq_mcap':round(max(0,min(15,(liq/mcap)/.5*15)),1),
            'smart_wallets':round(max(0,min(20,smart/12*20)),1),
        }
        return round(sum(components.values()),1), components


class Risk:
    name='RISK'
    def __init__(self,settings):self.s=settings
    def approve(self,broker):
        if broker.day_pnl() <= -broker.initial_balance*self.s.daily_loss_limit_pct:
            return 'дневният лимит загуба е достигнат'
        if len(broker.positions)>=self.s.max_positions:
            return 'лимит на едновременни позиции'
        if broker.cash<=0:return 'няма свободен paper баланс'
        return None


class PaperBroker:
    """Illustrative, NON-executable paper accounting only. No wallet/keys/network writes."""
    def __init__(self,settings,journal):
        self.s=settings;self.j=journal
        self.initial_balance=settings.initial_balance_usd
        self.cash=self.initial_balance
        self.positions={}
        self.prices={}
        self.realized=0.0
        self.day_start_equity=self.initial_balance
        self.day_utc=dt.datetime.now(UTC).date()
        self.trades=0
        saved=journal.load_state()
        if saved:
            self.cash=float(saved['cash'])
            self.positions=saved['positions']
            self.prices={k:float(v) for k,v in saved['prices'].items()}
            self.realized=float(saved['realized'])
            self.day_start_equity=float(saved['day_start_equity'])
            self.day_utc=dt.date.fromisoformat(saved['day_utc'])
            self.trades=int(saved['trades'])

    def persist(self):
        self.j.save_state({'cash':self.cash,'positions':self.positions,'prices':self.prices,
                           'realized':self.realized,'day_start_equity':self.day_start_equity,
                           'day_utc':self.day_utc.isoformat(),'trades':self.trades})

    def equity(self):
        return self.cash+sum(p['units']*self.prices.get(mint,p['entry_price']) for mint,p in self.positions.items())

    def day_pnl(self):
        day=dt.datetime.now(UTC).date()
        if day!=self.day_utc:
            self.day_utc=day;self.day_start_equity=self.equity()
        return self.equity()-self.day_start_equity

    def buy(self,mint,symbol,price,score):
        if mint in self.positions:return False
        budget=min(self.equity()*self.s.max_alloc_pct,self.cash)
        if budget<1:return False
        executed=price*(1+self.s.paper_slippage_pct)
        units=budget*(1-self.s.paper_fee_pct)/executed
        if units<=0:return False
        self.cash-=budget
        self.positions[mint]=dict(symbol=symbol,units=units,entry_price=executed,entry_cost=budget,
                                  high=price,stop=executed*(1-self.s.stop_loss_pct),trailing=False,score=score,
                                  entered_at=timestamp())
        self.prices[mint]=price
        self.trades+=1
        self.j.log('EXECUTOR','PAPER_BUY',f'cost=${budget:.2f}, observed_price={price:.10g}, paper_fill={executed:.10g}, score={score}',mint,symbol)
        self.j.record_equity(self.equity())
        self.persist()
        return True

    def mark(self,mint,price):
        if not number(price) or price<=0:return
        self.prices[mint]=price
        p=self.positions.get(mint)
        if not p:return
        p['high']=max(p['high'],price)
        if price>=p['entry_price']*(1+self.s.trail_trigger_pct):p['trailing']=True
        if p['trailing']:p['stop']=max(p['stop'],p['high']*(1-self.s.trail_distance_pct))
        if price<=p['stop']:
            self.sell(mint,price,'PAPER_STOP' if not p['trailing'] else 'PAPER_TRAILING_STOP')
        else:self.persist()

    def sell(self,mint,price,reason):
        p=self.positions.pop(mint,None)
        if not p:return False
        fill=price*(1-self.s.paper_slippage_pct)
        proceeds=p['units']*fill*(1-self.s.paper_fee_pct)
        pnl=proceeds-p['entry_cost']
        self.cash+=proceeds
        self.realized+=pnl
        self.j.log('RISK',reason,f'proceeds=${proceeds:.2f}, net_pnl=${pnl:.2f}; stop simulated by snapshots, not guaranteed',mint,p['symbol'])
        self.j.record_equity(self.equity())
        self.persist()
        return True


class Desk:
    def __init__(self,root,settings=None,market=None,gmgn=None):
        self.s=settings or Settings();self.root=Path(root)
        self.root.mkdir(parents=True,exist_ok=True)
        self.j=Journal(self.root/'desk.sqlite3');self.dex=market or DexScreener()
        self.gmgn=gmgn or GMGN();self.scout=Scout(self.s);self.filter=Filter(self.s)
        self.analyst=Analyst(self.s);self.risk=Risk(self.s);self.paper=PaperBroker(self.s,self.j)
        self.lock=threading.RLock();self.running=False;self.worker=None;self.candidates={}
        self.scanned=0;self.killed=0;self.qualified=0;self.last_cycle=None
        self.phase='IDLE';self.last_error='';self.mode='PAPER_ONLY'
        self.j.record_equity(self.paper.equity())
        self.j.log('LOGGER','BOOT','PAPER_ONLY. No keys, no real orders. Real market samples require internet; security evidence is mandatory.')

    def run_cycle(self):
        with self.lock:
            self.phase='SCOUT';self.last_cycle=timestamp()
        try:
            pairs=self.dex.discover()
        except Exception as exc:
            self.j.log('SCOUT','ERROR',f'{type(exc).__name__}: market request failed')
            with self.lock:self.last_error='неуспешен DexScreener market request';self.phase='ERROR'
            return
        if not pairs:self.j.log('SCOUT','EMPTY','Няма открити нови Solana кандидати от sampling feed; не е all-pairs firehose.')
        for pair in pairs[:12]:
            if not self.running:break
            mint=(pair.get('baseToken') or {}).get('address','')
            symbol=(pair.get('baseToken') or {}).get('symbol','?')
            if not mint:continue
            with self.lock:
                self.scanned+=1; self.phase='FILTER'
                reasons,market=self.scout.assess(pair)
                current=self.candidates.get(mint,{})
                # Last data timestamp is source observation, not chain block time.
                self.candidates[mint]={'mint':mint,'symbol':symbol,'price':market['price'],
                        'mcap':market['mcap'],'liquidity':market['liquidity'],'age_min':market['age_min'],
                        'score':current.get('score'), 'status':'SCANNING','reason':'','updated_at':timestamp()}
                if market['price'] is not None:self.paper.mark(mint,market['price'])
                if reasons:self._kill(mint,symbol,'SCOUT',reasons);continue
            try:
                evidence=self.gmgn.evidence(mint)
            except MissingEvidence as exc:
                with self.lock:self._kill(mint,symbol,'FILTER',[str(exc)]);continue
            with self.lock:
                reasons=self.filter.assess(pair,market,evidence)
                if reasons:self._kill(mint,symbol,'FILTER',reasons);continue
                self.phase='ANALYST'
                try:score,parts=self.analyst.assess(pair,market,evidence)
                except MissingEvidence as exc:
                    self._kill(mint,symbol,'ANALYST',[str(exc)]);continue
                self.candidates[mint].update(score=score,components=parts)
                if score < self.s.min_score:
                    self._kill(mint,symbol,'ANALYST',[f'оценка {score:.1f}/100 < {self.s.min_score}']);continue
                self.qualified+=1;self.phase='RISK'
                failure=self.risk.approve(self.paper)
                if failure:
                    self._kill(mint,symbol,'RISK',[failure]);continue
                if mint in self.paper.positions:
                    self.candidates[mint].update(status='HELD',reason='paper позицията вече е отворена');continue
                self.phase='EXECUTOR'
                if self.paper.buy(mint,symbol,market['price'],score):
                    self.candidates[mint].update(status='PAPER_OPEN',reason='paper buy at illustrative slip/fee')
                else:self._kill(mint,symbol,'EXECUTOR',['paper buy denied: insufficient cash or duplicate'])
        # Network calls must never hold the dashboard lock.
        with self.lock:
            open_mints=list(self.paper.positions)
        for mint in open_mints:
            try:
                pair=self.dex.token_pair(mint)
                if pair:
                    price=number(pair.get('priceUsd'))
                    if price and price>0:
                        with self.lock:self.paper.mark(mint,price)
            except Exception:
                self.j.log('RISK','STALE_PRICE','Could not refresh market price; stop cannot be simulated reliably',mint)
        with self.lock:
            self.paper.j.record_equity(self.paper.equity())
            self.phase='IDLE'

    def _kill(self,mint,symbol,agent,reasons):
        reason='; '.join(reasons)
        self.killed+=1
        self.candidates[mint].update(status='REJECTED',reason=reason,score=self.candidates[mint].get('score'))
        self.j.log(agent,'KILL',reason,mint,symbol)

    def start(self):
        with self.lock:
            if self.running:return False
            self.running=True;self.worker=threading.Thread(target=self._loop,daemon=True,name='solana-paper-desk');self.worker.start()
            self.j.log('LOGGER','START','Paper-only desk started. Overnight requires this computer to remain awake.')
            return True

    def stop(self):
        with self.lock:
            self.running=False;self.j.log('LOGGER','STOP','Paper scanning disabled; existing paper positions remain open.')

    def _loop(self):
        while self.running:
            try:self.run_cycle()
            except Exception as exc:
                self.j.log('LOGGER','ERROR',f'{type(exc).__name__}: unexpected desk cycle failure')
                with self.lock:self.last_error='вътрешна грешка: '+type(exc).__name__;self.phase='ERROR'
            for _ in range(self.s.scan_seconds):
                if not self.running:return
                time.sleep(1)

    def status(self):
        with self.lock:
            return {'mode':self.mode,'running':self.running,'phase':self.phase,
              'last_cycle':self.last_cycle,'last_error':self.last_error,
              'data_source':'DexScreener public latest profiles/boosts — sampled, not all new pairs',
              'security_source':'GMGN official CLI' if self.gmgn.executable else 'MISSING — all trade candidates fail closed',
              'scanned':self.scanned,'killed':self.killed,'qualified':self.qualified,
              'cash':round(self.paper.cash,4),'equity':round(self.paper.equity(),4),
              'realized':round(self.paper.realized,4),'positions':len(self.paper.positions),
              'open_positions':[{'mint':m,**p,'mark':self.paper.prices.get(m)} for m,p in self.paper.positions.items()],
              'candidates':list(reversed(list(self.candidates.values())[-40:])),
              'events':self.j.events(90),'equity_curve':self.j.equity(100),
              'rules':dataclasses.asdict(self.s),
              'agents':['SCOUT','FILTER','ANALYST','EXECUTOR','RISK','LOGGER']}
