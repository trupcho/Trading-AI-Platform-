# Trading AI · Solana Memecoin Desk v0.1 — PAPER ONLY

Това е **нов, отделен проект** от Trading AI / OANDA MT5. OANDA, MetaTrader и ChatGPT не са необходими. Сканира Solana кандидати през публичния DexScreener API. Приложението е локално и се отваря в браузъра на `http://127.0.0.1:8777`.

**Режим:** PAPER ONLY. Няма портфейл, частни ключове, on-chain подписване или реални сделки. Няма и доказана печеливша стратегия. Нито една нощна симулация не е достатъчна за реална търговия.

## Стартиране

- **Windows EXE:** ако GitHub Actions е компилирал `Trading_AI_Solana_Desk_v0.1.exe`, стартирай директно. Не е необходим Python. Остави компютъра включен и без Sleep, докато работи.
- **Изходен код:** изисква Python 3.11+; отвори `run_solana_desk.bat` (Windows) или изпълни `python -m solana_desk` от основната директория.
- **Спиране:** натисни `■ Спри`, след което можеш да затвориш програмата. STOP спира сканирането, но не прави продажби на отворени paper позиции.
- **Логове:** съхраняват се локално в `%USERPROFILE%\TradingAI-SolanaPaper\desk.sqlite3`. Не се изпращат към GitHub.

## Шест агента, твърди handoffs

`SCOUT → FILTER → ANALYST → RISK preflight → EXECUTOR (PAPER) → LOGGER`. RISK продължава да следи paper позициите. Всеки отказ се записва с причина.

- SCOUT: възраст на двойката от DexScreener 30 минути–72 часа, market cap (или маркиран FDV proxy) $300k–$20M;
- FILTER: liquidity/marketcap **≥25%**, ръст за 1h **<80%**, mint/freeze revoked, ликвидност доказано locked/burned, top10 holders ≤25%, dev holdings ≤3%, bundled launch ≤10%, никаква потвърдена предишна dev rug история;
- ANALYST: прозрачна **евристика** 0–100 върху momentum, unique buyers, buy/sell count, holder growth, liq/mcap, smart wallets. Изисква всички реални метрики; липсващите данни = REJECTED. Оценка ≥70 дава право само на paper risk preflight;
- EXECUTOR: до 8% от paper equity на сделка, максимум три позиции, без averaging down;
- RISK: −6% paper stop, trailing активира се над +12%, следи 6% от peak; дневен лимит загуба 3% от началната paper сума. Стопове са симулирани на периодично наблюдавана цена, не гарантирани ордери;
- LOGGER: всеки KILL, PAPER_BUY, STOP, грешка и серия equity в SQLite.

## Важни ограничения на реалните данни

DexScreener public `token-profiles/latest/v1` + `token-boosts/latest/v1` **не сканират всички нови Solana двойки**. Това са sample feeds, а не tick-by-tick streaming. Данните за ликвидност/цена/транзакции са реални snapshot-и, когато API работи; при липса на интернет няма scan.

За доказателства за contract safety и уникални/различни портфейли е необходим **GMGN Agent API** (https://docs.gmgn.ai/index/gmgn-agent-api) или друга надеждна on-chain услуга. Налична е опционална интеграция с **официалния GMGN CLI**, ако на твоя компютър има инсталиран `gmgn-cli` и е конфигуриран със собствен API key. За да го разрешиш, задай системната променлива `GMGN_CLI_BIN` на абсолютния път до `gmgn-cli.cmd` или executable. Не изпращай API ключове в чат и не ги добавяй в GitHub. Без конфигуриран инструмент **всички кандидати се отхвърлят**. Същото важи при непознат формат на полетата: не предполагаме, че security проверката е успешна.

GMGN CLI полетата могат да се променят. При извикване програмата чете суров JSON и изисква явно доказани полета за LP lock, creator past rugs, dev/bundle концентрация и реални unique buyers. Ако GMGN не предоставя някое поле — отказва. Това е нарочно за безопасност и трябва да се разшири с конкретен надежден доставчик за тези сигнали, преди автоматично paper trading да е практическо.

**Централни източници:** [DexScreener API](https://docs.dexscreener.com/api/reference), [GMGN Agent API](https://docs.gmgn.ai/index/gmgn-agent-api), [GMGN CLI](https://github.com/GMGNAI/gmgn-skills/blob/main/docs/cli-usage.md), [Solana token verification](https://solana.com/docs/tokens/how-to-verify-a-token).

## Следващи инженерни задачи преди реална версия

Истинско пълно discover (напр. websocket on-chain нови pool-и), GMGN/Birdeye/Helius provider contracts за dev rugs, LP locks, bundle origins, unique buyers; тестове за обновяване на snapshot-и с реален API; независим paper performance audit и разходи; доказана score calibration; wallet подписване с отделни права и човешко одобрение; слippage/MEV/fees; сигурен kill-switch и лимити. **Няма да включваме реална търговия автоматично.**
