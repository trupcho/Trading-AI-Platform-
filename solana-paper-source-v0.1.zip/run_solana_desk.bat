@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
 echo Python 3.11+ is required for the source version. Use the Windows EXE once published.
 pause
 exit /b 1
)
py -3 -m solana_desk
pause
