#define MyAppName "Trading AI Desktop"
#define MyAppVersion "0.8.0"
#define MyAppExeName "TradingAI-Desktop.exe"

[Setup]
AppId={{2AA8F494-5BD0-4FD8-B442-3D3B7619E8F1}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion}
AppPublisher=Trading AI Desktop
DefaultDirName={localappdata}\Programs\Trading AI Desktop
DefaultGroupName=Trading AI
PrivilegesRequired=lowest
OutputDir=..\dist
OutputBaseFilename=Trading_AI_Desktop_Setup_v0.8
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
SetupLogging=yes
UninstallDisplayIcon={app}\{#MyAppExeName}
DisableProgramGroupPage=yes

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Създай икона на работния плот"; Flags: unchecked

[Files]
Source: "..\dist\{#MyAppExeName}"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\Trading AI Desktop"; Filename: "{app}\{#MyAppExeName}"
Name: "{userdesktop}\Trading AI Desktop"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Отвори Trading AI Desktop"; Flags: nowait postinstall skipifsilent
