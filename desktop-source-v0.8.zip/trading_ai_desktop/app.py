"""Trading AI desktop: Tk interface for a LOCAL MetaTrader5 terminal.

This app has no remote API and never sends credentials to GitHub.
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path
from queue import Queue, Empty
import tkinter as tk
import threading
from tkinter import ttk, messagebox, filedialog
from typing import Any

from .core import Connection, TradingWorker

BG = '#0c121d'
PANEL = '#182334'
PANEL2 = '#111b29'
GOLD = '#e8c075'
WHITE = '#f5f6fa'
MUTED = '#a4b6c9'
RED = '#ff9696'
GREEN = '#65d9ac'
FONT = 'Segoe UI'


class Desktop(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('Trading AI Desktop · Setup Edition 0.8')
        self.geometry('1060x780')
        self.minsize(830, 640)
        self.configure(bg=BG)
        self.protocol('WM_DELETE_WINDOW', self.close)
        self.events: Queue = Queue()
        self.worker = TradingWorker(lambda name, data: self.events.put((name, data)))
        self.worker.start_thread()
        self.connected = False
        self.wizard = None
        self.running = False
        self.demo = False
        self.login = tk.StringVar()
        self.server = tk.StringVar()
        self.password = tk.StringVar()
        self.terminal = tk.StringVar()
        self.symbols = tk.StringVar(value='XAUUSD, EURUSD')
        self.ai_required = tk.BooleanVar(value=False)
        self.ai_symbol = tk.StringVar(value='XAUUSD')
        self.balance = tk.StringVar(value='—')
        self.equity = tk.StringVar(value='—')
        self.profit = tk.StringVar(value='—')
        self.positions = tk.StringVar(value='—')
        self.mode = tk.StringVar(value='DISCONNECTED')
        self.account_name = tk.StringVar(value='Не е свързана брокерска сметка')
        self.risk = tk.StringVar(value='≤ €0,25 / сделка')
        self._configure_style()
        self._build()
        self.after(250, self._process_events)
        self.after(600, self._show_setup)

    def _configure_style(self):
        st = ttk.Style(self)
        st.theme_use('clam')
        st.configure('TFrame', background=BG)
        st.configure('Panel.TFrame', background=PANEL)
        st.configure('TLabel', background=BG, foreground=WHITE, font=(FONT, 10))
        st.configure('Sub.TLabel', background=BG, foreground=MUTED, font=(FONT, 10))
        st.configure('Panel.TLabel', background=PANEL, foreground=WHITE, font=(FONT, 11))
        st.configure('Entry.TEntry', foreground=WHITE, fieldbackground='#101b2a',
                     bordercolor='#445976', padding=9)
        st.configure('TButton', font=(FONT, 10, 'bold'), padding=12,
                     background='#293e5a', foreground=WHITE, bordercolor='#536e8e')
        st.map('TButton', background=[('active', '#405a7a'), ('disabled', '#1c293a')],
               foreground=[('disabled', '#77889c')])
        st.configure('Gold.TButton', background='#80623b', foreground='#ffffff')
        st.map('Gold.TButton', background=[('active', '#aa8249'), ('disabled', '#3e342b')])
        st.configure('Red.TButton', background='#663b43', foreground=WHITE)
        st.map('Red.TButton', background=[('active', '#88414e')])
        st.configure('TNotebook', background=BG, borderwidth=0)
        st.configure('TNotebook.Tab', padding=(18, 12), font=(FONT, 10, 'bold'),
                     background='#172437', foreground=MUTED)
        st.map('TNotebook.Tab', background=[('selected', '#31435a')],
               foreground=[('selected', WHITE)])

    def _label(self, parent, text, *, size=10, color=WHITE, bold=False, bg=BG):
        return tk.Label(parent, text=text, fg=color, bg=bg,
                        font=(FONT, size, 'bold' if bold else 'normal'), anchor='w')

    def _build(self):
        frame = tk.Frame(self, bg=BG)
        frame.pack(fill='both', expand=True, padx=24, pady=18)
        top = tk.Frame(frame, bg=BG)
        top.pack(fill='x')
        self._label(top, 'TRADING', size=19, bold=True).pack(side='left')
        self._label(top, ' AI', size=19, bold=True, color=GOLD).pack(side='left')
        ttk.Button(top, text='⚙ Настройка', command=self._show_setup).pack(side='right', padx=8)
        self._label(top, 'LOCAL MT5  ·  NO CLOUD', size=9, color=GOLD).pack(side='right')
        self._label(frame, 'Твоят автоматизиран трейдинг — под контрол.', size=24, bold=True).pack(fill='x', pady=(20, 4))
        self._label(frame,
                    'Свързване към инсталиран MT5 терминал. Реална сметка: само наблюдение. Демо сметка: автоматизирани тестови сделки.',
                    color=MUTED).pack(fill='x', pady=(0, 16))
        note = tk.Frame(frame, bg='#30241d', highlightbackground='#735437', highlightthickness=1)
        note.pack(fill='x', pady=(0, 17))
        self._label(note, 'ВАЖНО: реални поръчки НЕ са активирани. Сигналите са от локален EMA/RSI/ATR агент, '
                    'а не от облачния TradingAgents модел. Печалба не е гарантирана.',
                    size=9, color='#f0d1a5', bg='#30241d').pack(fill='x', padx=14, pady=11)
        tabs = ttk.Notebook(frame)
        tabs.pack(fill='both', expand=True)
        board = ttk.Frame(tabs)
        tabs.add(board, text='Табло и управление')
        analysis = ttk.Frame(tabs)
        tabs.add(analysis, text='Риск и агент')
        help_tab = ttk.Frame(tabs)
        tabs.add(help_tab, text='Инструкции')
        self._dashboard(board)
        self._risk_panel(analysis)
        self._help_panel(help_tab)

    def _card(self, parent, label: str, variable: tk.StringVar):
        w = tk.Frame(parent, bg=PANEL, highlightbackground='#304159', highlightthickness=1)
        self._label(w, label, color=MUTED, size=9, bg=PANEL).pack(anchor='w', padx=16, pady=(13, 5))
        tk.Label(w, textvariable=variable, bg=PANEL, fg=WHITE,
                 font=(FONT, 21, 'bold'), anchor='w').pack(anchor='w', padx=16, pady=(0, 15))
        return w

    def _dashboard(self, parent):
        parent.columnconfigure(0, weight=1)
        parent.columnconfigure(1, weight=1)
        body = tk.Frame(parent, bg=BG)
        body.pack(fill='both', expand=True, padx=2, pady=13)
        stats = tk.Frame(body, bg=BG)
        stats.pack(fill='x')
        for i in range(4):
            stats.grid_columnconfigure(i, weight=1)
        for i, (name, variable) in enumerate([
            ('Баланс', self.balance), ('Equity', self.equity),
            ('Open P&L', self.profit), ('Позиции', self.positions),
        ]):
            card = self._card(stats, name, variable)
            card.grid(row=0, column=i, sticky='nsew', padx=(0 if i == 0 else 7, 0))
        auth = tk.Frame(body, bg=PANEL, highlightbackground='#304159', highlightthickness=1)
        auth.pack(fill='x', pady=(14, 0))
        top = tk.Frame(auth, bg=PANEL)
        top.pack(fill='x', padx=15, pady=(13, 4))
        self._label(top, 'MT5 акаунт', size=12, bold=True, bg=PANEL).pack(side='left')
        tk.Label(top, textvariable=self.mode, fg=GOLD, bg=PANEL, font=(FONT, 10, 'bold')).pack(side='right')
        tk.Label(auth, textvariable=self.account_name, fg=MUTED, bg=PANEL,
                 anchor='w', font=(FONT, 9)).pack(fill='x', padx=15)
        fields = tk.Frame(auth, bg=PANEL)
        fields.pack(fill='x', padx=14, pady=12)
        for i in range(3): fields.grid_columnconfigure(i, weight=1)
        for i, (title, value, mask) in enumerate([
            ('MT5 Login (номер)', self.login, None), ('Server (от брокера)', self.server, None),
            ('Парола (не се запазва)', self.password, '•')
        ]):
            p = tk.Frame(fields, bg=PANEL)
            p.grid(row=0, column=i, sticky='ew', padx=(0 if i == 0 else 8, 0))
            self._label(p, title, size=9, color=MUTED, bg=PANEL).pack(anchor='w', pady=(0, 5))
            ttk.Entry(p, textvariable=value, show=mask).pack(fill='x')
        terminal = tk.Frame(auth, bg=PANEL)
        terminal.pack(fill='x', padx=14, pady=(0, 12))
        ttk.Entry(terminal, textvariable=self.terminal).pack(side='left', fill='x', expand=True)
        ttk.Button(terminal, text='Намери терминал', command=self._select_terminal).pack(side='left', padx=(9, 0))
        self._label(auth, 'Незадължително: път до metatrader64.exe (остави празно за автоматично откриване)',
                    size=9, color=MUTED, bg=PANEL).pack(anchor='w', padx=15, pady=(0, 10))
        actions = tk.Frame(auth, bg=PANEL)
        actions.pack(fill='x', padx=14, pady=(0, 14))
        self.connect_button = ttk.Button(actions, text='Свържи MT5', style='Gold.TButton', command=self._connect)
        self.connect_button.pack(side='left')
        ttk.Button(actions, text='Обнови', command=lambda:self.worker.send('scan')).pack(side='left', padx=10)
        ttk.Button(actions, text='Прекъсни', command=lambda:self.worker.send('disconnect')).pack(side='left')
        command = tk.Frame(body, bg=PANEL, highlightbackground='#304159', highlightthickness=1)
        command.pack(fill='x', pady=14)
        self._label(command, 'Автоматизация (само DEMO)', bg=PANEL, size=12, bold=True).pack(anchor='w', padx=15, pady=(13, 6))
        self._label(command, 'Символи от Market Watch, разделени със запетая · до 4 инструмента',
                    bg=PANEL, color=MUTED, size=9).pack(anchor='w', padx=15)
        ttk.Entry(command, textvariable=self.symbols).pack(fill='x', padx=15, pady=(8, 11))
        buttons = tk.Frame(command, bg=PANEL)
        buttons.pack(anchor='w', padx=15, pady=(0, 13))
        self.start_button = ttk.Button(buttons, text='▶ START DEMO', style='Gold.TButton',
                                       command=self._start)
        self.start_button.pack(side='left')
        ttk.Button(buttons, text='■ STOP', style='Red.TButton',
                   command=lambda:self.worker.send('stop')).pack(side='left', padx=9)
        self._label(command, 'STOP предотвратява нови поръчки; не затваря вече отворени позиции.',
                    size=9, color=RED, bg=PANEL).pack(anchor='w', padx=15, pady=(0, 11))
        logbox = tk.Frame(body, bg=PANEL, highlightbackground='#304159', highlightthickness=1)
        logbox.pack(fill='both', expand=True)
        self._label(logbox, 'Събития / MT5 одит', size=11, bold=True, bg=PANEL).pack(anchor='w', padx=15, pady=12)
        self.log = tk.Text(logbox, height=7, bg=PANEL2, fg='#dce4ef', relief='flat',
                           state='disabled', font=('Consolas', 9), padx=10, pady=8, wrap='word')
        self.log.pack(fill='both', expand=True, padx=15, pady=(0, 15))
        self._add_log('Приложението е готово. Инсталирай MetaTrader 5 и свържи демо сметка.')

    def _risk_panel(self, parent):
        content = tk.Frame(parent, bg=BG)
        content.pack(fill='both', expand=True, padx=15, pady=18)
        self._label(content, 'Конфигурация на защитата', size=19, bold=True).pack(anchor='w')
        rows = [
            ('Ограничен пилотен капитал', '€100 максимум'),
            ('Планиран риск на сделка', '0,25% (до €0,25 при €100)'),
            ('Дневна защита', '1% от началната equity за UTC деня'),
            ('Лимит на маржин', '35% от капитала до €100'),
            ('Едновременни позиции', '1 за цялата сметка'),
            ('Обем на позицията', 'Само минималния лот от MT5'),
            ('Инструменти', 'XAUUSD, EURUSD и други точни символи от брокера'),
            ('Източник на цени', 'Само MT5 (не изкуствени котировки)'),
            ('TradingAgents модел', 'Незадължителен research модул; не управлява ордери'),
            ('Реална търговия', 'Заключена — докато broker validation не е преминала'),
        ]
        for i, (k, v) in enumerate(rows):
            w = tk.Frame(content, bg=PANEL if i % 2 == 0 else PANEL2)
            w.pack(fill='x')
            self._label(w, k, bg=PANEL if i % 2 == 0 else PANEL2,
                        color=MUTED).pack(side='left', padx=14, pady=11)
            self._label(w, v, bg=PANEL if i % 2 == 0 else PANEL2,
                        color=GOLD).pack(side='right', padx=14)
        airow = tk.Frame(content, bg=BG)
        airow.pack(fill='x', pady=(12, 0))
        tk.Checkbutton(airow, text='Изисквай съвпадащо TradingAgents решение за всяка DEMO сделка',
                       variable=self.ai_required, command=self._set_ai_required,
                       bg=BG, fg=WHITE, selectcolor=PANEL, activebackground=BG,
                       activeforeground=WHITE, font=(FONT, 10)).pack(anchor='w')
        self._label(content, 'TradingAgents анализ (опционален, изисква конфигуриран LLM / ChatGPT вход)',
                    size=10, color=MUTED).pack(anchor='w', pady=(10, 5))
        ail = tk.Frame(content, bg=BG)
        ail.pack(anchor='w')
        ttk.Entry(ail, textvariable=self.ai_symbol, width=20).pack(side='left')
        ttk.Button(ail, text='Изпълни AI анализ', command=self._run_ai).pack(side='left', padx=10)
        self._label(content, 'Локалният сигнален агент използва затворени M5 свещи: EMA 9/21, EMA 50, RSI 14 и ATR 14.',
                    color=MUTED).pack(anchor='w', pady=(20, 5))
        self._label(content, 'Това е неизпитана инвестиционна стратегия, не обещание за доходност.',
                    color=RED).pack(anchor='w')

    def _help_panel(self, parent):
        content = tk.Frame(parent, bg=BG)
        content.pack(fill='both', expand=True, padx=15, pady=18)
        self._label(content, 'Първо стартиране', size=19, bold=True).pack(anchor='w')
        instructions = [
            '1. Инсталирай официалния MetaTrader 5 за Windows от избрания брокер.',
            '2. Създай безплатна MT5 DEMO сметка. Не внасяй пари.',
            '3. В Trading AI попълни Login номер, Server и парола от MT5.',
            '4. Натисни „Свържи MT5“ и провери дали балансът е действителен.',
            '5. Посочи точните имена на търговските инструменти от Market Watch.',
            '6. Натисни „START DEMO“; ако обемът/рискът не позволяват сделка, тя ще бъде отказана.',
            '7. Използвай STOP за спиране на новите заявки; управлявай откритите позиции в MT5.',
        ]
        for t in instructions:
            self._label(content, t, color=MUTED).pack(fill='x', pady=8)
        self._label(content, 'Трябва да останат включени компютърът и MT5 терминалът.',
                    color=GOLD, bold=True).pack(fill='x', pady=(20, 6))
        self._label(content, 'Паролата не се записва от приложението. MT5 терминалът сам управлява брокерската сесия.',
                    color=MUTED).pack(fill='x')
        self._label(content, 'Не давай пароли, токени или снимки с брокерски данни в ChatGPT или GitHub.',
                    color=RED).pack(fill='x', pady=6)

    def _show_setup(self):
        if self.wizard is not None and self.wizard.winfo_exists():
            self.wizard.lift()
            return
        from .first_run import SetupWizard
        self.wizard = SetupWizard(self)

    def _set_ai_required(self):
        self.worker.send('ai_required', value=self.ai_required.get())

    def _run_ai(self):
        symbol = self.ai_symbol.get().strip().upper()
        self._add_log('TradingAgents: анализът започва за ' + symbol + ' (може да отнеме време).')
        def work():
            try:
                from .ai import research
                report = research(symbol, self.worker.store.file.parent / 'ai_reports')
                self.events.put(('log', {'message': 'TradingAgents ' + symbol + ' → ' +
                                 report['action'] + ' (research, не разрешение за поръчка)'}))
            except Exception as exc:
                self.events.put(('log', {'message': 'TradingAgents анализът не е наличен: ' +
                                 type(exc).__name__ + '. Провери конфигурацията на AI.'}))
        threading.Thread(target=work, name='TradingAgentsResearch', daemon=True).start()

    def _select_terminal(self):
        f = filedialog.askopenfilename(title='Избери metatrader64.exe',
                                       filetypes=[('MT5 терминал', '*.exe')])
        if f: self.terminal.set(f)

    def _connect(self):
        try:
            login = int(self.login.get().strip())
        except ValueError:
            messagebox.showerror('Невалиден Login', 'MT5 Login трябва да е номер на сметка.')
            return
        if not self.password.get() or not self.server.get().strip():
            messagebox.showerror('Липсват данни', 'Попълни MT5 парола и Server.')
            return
        c = Connection(login, self.server.get().strip(), self.password.get(), self.terminal.get())
        self.password.set('')
        self.worker.send('connect', credentials=c)
        self._add_log('Свързване към MT5 терминала...')

    def _start(self):
        symbols = [x.strip() for x in self.symbols.get().split(',') if x.strip()]
        self.worker.send('start', symbols=symbols)

    def _add_log(self, text: str):
        self.log.configure(state='normal')
        self.log.insert('end', datetime.now().strftime('%H:%M:%S') + '  ' + text + '\n')
        self.log.see('end')
        self.log.configure(state='disabled')

    def _process_events(self):
        try:
            while True:
                event, data = self.events.get_nowait()
                if event == 'log':
                    self._add_log(data['message'])
                elif event == 'connected':
                    self.connected = True
                    self.demo = data['demo']
                    self.account_name.set(f"#{data['login']} · {data['server']} · {data['currency']}")
                    self.mode.set('DEMO CONNECTED' if self.demo else 'REAL · MONITOR ONLY')
                    if self.wizard is not None:
                        self.wizard.on_connected()
                elif event == 'disconnected':
                    self.connected = False
                    self.demo = False
                    self.account_name.set('Не е свързана брокерска сметка')
                    self.mode.set('DISCONNECTED')
                elif event == 'diagnostics':
                    if self.wizard is not None:
                        self.wizard.on_diagnostics(data)
                elif event == 'mode':
                    self.running = data['value'] == 'DEMO RUN'
                    self.mode.set(data['value'])
                elif event == 'status':
                    c = data['currency']
                    self.balance.set(f"{data['balance']:,.2f} {c}")
                    self.equity.set(f"{data['equity']:,.2f} {c}")
                    self.profit.set(f"{data['profit']:+,.2f} {c}")
                    self.positions.set(str(data['positions']))
                    self.risk.set(f"≤ {data['risk']:.2f} EUR")
                self.start_button.configure(state='normal' if self.connected and self.demo else 'disabled')
        except Empty:
            pass
        self.after(250, self._process_events)

    def close(self):
        if self.running and not messagebox.askyesno(
            'Спиране на Trading AI',
            'Затварянето спира автоматизацията, но НЕ затваря отворените позиции в MT5. Продължи?'):
            return
        self.worker.send('shutdown')
        self.destroy()


def main():
    Desktop().mainloop()


if __name__ == '__main__':
    main()
