"""Optional TradingAgents research integration.

The multi-agent LLM's upstream data feed is NOT the MT5 broker feed.
This module is research-only; only strict same-day directional veto is possible.
"""
from __future__ import annotations
from datetime import datetime, timezone
from pathlib import Path
import json
import os
from typing import Any

# Yahoo-proxy symbols; do not confuse them with MT5 executable quotes.
RESEARCH_SYMBOLS = {
    'XAUUSD': 'GC=F',
    'NAS100': '^NDX',
    'EURUSD': 'EURUSD=X',
    'GBPUSD': 'GBPUSD=X',
    'BTCUSD': 'BTC-USD',
}


def parse_action(value: Any) -> str:
    if not isinstance(value, str):
        return 'UNRESOLVED'
    raw = value.strip()
    if raw.upper() in {'BUY', 'SELL', 'HOLD'}:
        return raw.upper()
    try:
        obj = json.loads(raw)
    except (ValueError, TypeError):
        return 'UNRESOLVED'
    if isinstance(obj, dict) and set(obj) == {'action'}:
        action = obj['action']
        if isinstance(action, str) and action.strip().upper() in {'BUY', 'SELL', 'HOLD'}:
            return action.strip().upper()
    return 'UNRESOLVED'


def ai_permission(symbol: str, direction: str, folder: Path, *, today: str | None = None) -> bool:
    """Fail-closed: only exact market, proxy, UTC day and parsed direction."""
    if symbol not in RESEARCH_SYMBOLS or direction not in {'BUY', 'SELL'}:
        return False
    today = today or datetime.now(timezone.utc).date().isoformat()
    try:
        record = json.loads((folder / f'{symbol}_{today}.json').read_text(encoding='utf8'))
    except (OSError, json.JSONDecodeError, UnicodeError):
        return False
    return (record.get('market') == symbol
            and record.get('proxy') == RESEARCH_SYMBOLS[symbol]
            and record.get('date_utc') == today
            and record.get('action') == direction
            and record.get('approved') is False)


def research(symbol: str, folder: Path, *, provider: str | None = None) -> dict:
    """Run actual optional upstream TradingAgents model, not the EMA strategy.

    Requires locally installed TradingAgents and user-selected provider login
    (ChatGPT subscription OAuth, paid API key or Ollama), never broker password.
    """
    if symbol not in RESEARCH_SYMBOLS:
        raise ValueError(f'No verified research-proxy mapping for {symbol}')
    try:
        from tradingagents.graph.trading_graph import TradingAgentsGraph
        from tradingagents.default_config import DEFAULT_CONFIG
    except ImportError as exc:
        raise RuntimeError('TradingAgents not installed. See README and INSTALL_AI.bat') from exc
    cfg = DEFAULT_CONFIG.copy()
    selected = provider or os.environ.get('TRADINGAGENTS_LLM_PROVIDER', '').strip()
    if selected:
        cfg['llm_provider'] = selected
    today = datetime.now(timezone.utc).date().isoformat()
    model = TradingAgentsGraph(debug=False, config=cfg)
    _state, decision = model.propagate(RESEARCH_SYMBOLS[symbol], today)
    action = parse_action(str(decision))
    report = {
        'market': symbol, 'proxy': RESEARCH_SYMBOLS[symbol],
        'date_utc': today, 'action': action, 'approved': False,
        'raw_decision': str(decision)[:6000],
        'data_warning': 'TradingAgents proxy != broker live prices; veto only, never execution authority',
    }
    folder.mkdir(parents=True, exist_ok=True)
    (folder / f'{symbol}_{today}.json').write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding='utf8')
    return report
