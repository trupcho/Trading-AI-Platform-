import json
import tempfile
import time
import unittest
from pathlib import Path
from types import SimpleNamespace as S
from unittest.mock import patch

from trading_ai_desktop.ai import parse_action, ai_permission
from trading_ai_desktop.core import (Connection, TradingWorker, AuditStore,
                                     Signal, analyze_bars, ema, rsi)


class DummyMT5:
    ACCOUNT_TRADE_MODE_DEMO = 0
    ACCOUNT_TRADE_MODE_REAL = 2
    SYMBOL_TRADE_MODE_FULL = 4
    TIMEFRAME_M5 = 5
    ORDER_TYPE_BUY = 0
    ORDER_TYPE_SELL = 1
    ORDER_FILLING_IOC = 1
    ORDER_FILLING_FOK = 0
    TRADE_ACTION_DEAL = 1
    ORDER_TIME_GTC = 0
    TRADE_RETCODE_DONE = 10009

    def __init__(self, demo=True):
        self.account = S(login=6001, server='Broker-Demo', trade_mode=0 if demo else 2,
                         currency='EUR', trade_allowed=True, balance=100, equity=100, profit=0)
        self.info = S(visible=True, trade_mode=4, volume_min=.0001,
                      volume_max=100, volume_step=.0001, point=.01,
                      trade_tick_size=.01, trade_stops_level=0, filling_mode=2)
        self.tick = S(time=int(time.time()), bid=4000, ask=4000.05)
        self.orders_sent = 0
        self.positions = []
        self.orders = []
        self.fail_check = False
        self.last_request = None
        self.init = False

    def initialize(self, *args, **kwargs):
        self.init = True
        return True
    def shutdown(self): self.init = False
    def account_info(self): return self.account
    def symbol_info(self, s): return self.info
    def symbol_select(self, s, v): return True
    def symbol_info_tick(self, s): return self.tick
    def copy_rates_from_pos(self, *args):
        return [{'time': 1000+i*300, 'open':4000, 'close':4000+i*.0001,
                 'high':4000.5,'low':3999.5} for i in range(100)]
    def terminal_info(self): return S(trade_allowed=True)
    def positions_get(self): return self.positions
    def orders_get(self): return self.orders
    def order_calc_margin(self, side, symbol, volume, price): return 20 * (volume / .0001)
    def order_calc_profit(self, side, symbol, volume, entry, stop): return -0.1 * (volume / .0001)
    def order_check(self, request):
        self.last_request = request
        return S(retcode=0 if not self.fail_check else 10013)
    def order_send(self, request):
        self.orders_sent += 1
        self.last_request = request
        return S(retcode=self.TRADE_RETCODE_DONE)


class DesktopTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.events=[]
        self.mt=DummyMT5()
        self.engine=TradingWorker(lambda event, data: self.events.append((event,data)),
                                  mt5=self.mt, data_dir=Path(self.tmp.name))
        self.engine._connect(Connection(6001,'Broker-Demo','fake'))

    def test_password_erased_after_login(self):
        c=Connection(6001,'Broker-Demo','not-to-store')
        self.engine._connect(c)
        self.assertEqual(c.password,'')
        self.assertFalse(any('not-to-store' in str(x) for x in self.events))

    def test_demo_real_market_order_after_risk_preflight(self):
        self.engine._start(['XAUUSD'])
        with patch('trading_ai_desktop.core.analyze_bars', return_value=Signal('BUY','test',1.0,12345)):
            self.engine._refresh()
        self.assertEqual(self.mt.orders_sent,1)
        self.assertGreater(self.mt.last_request['tp'],self.mt.last_request['price'])
        self.assertLess(self.mt.last_request['sl'],self.mt.last_request['price'])
        self.assertEqual(self.mt.last_request['volume'],0.0001)
        self.assertTrue(self.mt.last_request['comment'].startswith('TradingAI-Demo'))

    def test_no_repeat_order_after_restart_same_bar(self):
        self.engine._start(['XAUUSD'])
        with patch('trading_ai_desktop.core.analyze_bars',return_value=Signal('BUY','test',1.0,12345)):
            self.engine._refresh()
            self.engine._refresh()
        self.assertEqual(self.mt.orders_sent,1)

    def test_large_minimum_lot_blocks(self):
        self.mt.info.volume_min=0.01
        self.engine._start(['XAUUSD'])
        with patch('trading_ai_desktop.core.analyze_bars',return_value=Signal('BUY','test',1.0,12345)):
            self.engine._refresh()
        self.assertEqual(self.mt.orders_sent,0)

    def test_position_block(self):
        self.mt.positions=[S(ticket=12)]
        self.engine._start(['XAUUSD'])
        with patch('trading_ai_desktop.core.analyze_bars',return_value=Signal('BUY','test',1.0,12345)):
            self.engine._refresh()
        self.assertEqual(self.mt.orders_sent,0)

    def test_stop_file_block(self):
        (Path(self.tmp.name)/'STOP_TRADING').write_text('stop')
        self.engine._start(['XAUUSD'])
        with patch('trading_ai_desktop.core.analyze_bars',return_value=Signal('BUY','test',1.0,12345)):
            self.engine._refresh()
        self.assertEqual(self.mt.orders_sent,0)
        self.assertFalse(self.engine.running)

    def test_real_account_monitor_only(self):
        mt=DummyMT5(demo=False)
        e=TradingWorker(lambda ev,d:None,mt5=mt,data_dir=Path(self.tmp.name))
        e._connect(Connection(6001,'Broker-Demo','fake'))
        e._start(['XAUUSD'])
        self.assertFalse(e.running)
        with patch('trading_ai_desktop.core.analyze_bars',return_value=Signal('BUY','test',1.0,12345)):
            e._refresh()
        self.assertEqual(mt.orders_sent,0)

    def test_stale_tick_no_trade(self):
        self.mt.tick.time=int(time.time())-300
        self.engine._start(['XAUUSD'])
        with patch('trading_ai_desktop.core.analyze_bars',return_value=Signal('BUY','test',1.0,12345)):
            self.engine._refresh()
        self.assertEqual(self.mt.orders_sent,0)

    def test_daily_drawdown_halts(self):
        self.engine._refresh()  # persist baseline 100
        self.mt.account.equity=98.9
        self.engine._start(['XAUUSD'])
        self.engine._refresh()
        self.assertFalse(self.engine.running)
        self.assertEqual(self.mt.orders_sent,0)

    def test_ai_gate_fails_without_report(self):
        self.engine._start(['XAUUSD'])
        self.engine.require_ai = True
        with patch('trading_ai_desktop.core.analyze_bars',return_value=Signal('BUY','test',1.0,12345)):
            self.engine._refresh()
        self.assertEqual(self.mt.orders_sent,0)

    def test_ai_gate_allows_research_veto(self):
        from datetime import datetime,timezone
        today=datetime.now(timezone.utc).date().isoformat()
        folder=Path(self.tmp.name)/'ai_reports';folder.mkdir()
        (folder/f'XAUUSD_{today}.json').write_text(json.dumps(dict(market='XAUUSD',proxy='GC=F',date_utc=today,
            action='BUY',approved=False,provider='chatgpt',generated_at_epoch=time.time())))
        self.engine.require_ai = True
        self.engine._start(['XAUUSD'])
        with patch('trading_ai_desktop.core.analyze_bars',return_value=Signal('BUY','test',1.0,12345)):
            self.engine._refresh()
        self.assertEqual(self.mt.orders_sent,1)

    def test_broker_preflight_rejects(self):
        self.mt.fail_check=True
        self.engine._start(['XAUUSD'])
        with patch('trading_ai_desktop.core.analyze_bars',return_value=Signal('BUY','test',1.0,12345)):
            self.engine._refresh()
        self.assertEqual(self.mt.orders_sent,0)

    def test_trade_permission_disabled(self):
        self.mt.account.trade_allowed=False
        self.engine._start(['XAUUSD'])
        with patch('trading_ai_desktop.core.analyze_bars',return_value=Signal('BUY','test',1.0,12345)):
            self.engine._refresh()
        self.assertEqual(self.mt.orders_sent,0)

    def test_broker_switches_to_real_during_preflight(self):
        original=self.mt.order_check
        def switched(req):
            self.mt.account.trade_mode=self.mt.ACCOUNT_TRADE_MODE_REAL
            return original(req)
        self.mt.order_check=switched
        self.engine._start(['XAUUSD'])
        with patch('trading_ai_desktop.core.analyze_bars',return_value=Signal('BUY','test',1.0,12345)):
            self.engine._refresh()
        self.assertEqual(self.mt.orders_sent,0)
        self.assertFalse(self.engine.running)

    def test_non_eur_account_disallows_demo(self):
        self.mt.account.currency='USD'
        self.engine._start(['XAUUSD'])
        with patch('trading_ai_desktop.core.analyze_bars',return_value=Signal('BUY','test',1.0,12345)):
            self.engine._refresh()
        self.assertEqual(self.mt.orders_sent,0)

    def test_agent_parser(self):
        self.assertEqual(parse_action('BUY'),'BUY')
        self.assertEqual(parse_action('{"action":"BUY"}'),'BUY')
        self.assertEqual(parse_action('BUY because ...'),'UNRESOLVED')
        self.assertEqual(parse_action('{"action":"BUY","approved":true}'),'UNRESOLVED')

    def test_audit_idempotency(self):
        store=AuditStore(Path(self.tmp.name))
        self.assertTrue(store.reserve_order('one','123'))
        self.assertFalse(store.reserve_order('two','123'))
        store.finish('one','DONE','ok')
        self.assertTrue(store.reserve_order('two','123'))
        self.assertFalse(store.reserve_order('two','123'))

    def test_signal_does_not_trade_without_bars(self):
        self.assertEqual(analyze_bars([]).direction,'WAIT')
        self.assertAlmostEqual(ema([1.0]*100, 9)[-1], 1.0)
        self.assertEqual(rsi([1.0]*100), 50.0)


if __name__ == '__main__': unittest.main()
