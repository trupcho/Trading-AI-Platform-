"""Browser endpoint and cancellation regression tests, no actual broker orders."""
import http.client
import json
from datetime import datetime, timezone
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest.mock import patch

from trading_ai_desktop.browser_server import AppServer, Controller
from test_desktop_core import DummyMT5


class BrowserTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.mt = DummyMT5()
        self.ctrl = Controller(mt5=self.mt, data_dir=Path(self.tmp.name), auto_auth_check=False)
        self.httpd = AppServer(('127.0.0.1', 0), self.ctrl)
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.thread.start()
        self.addCleanup(self.cleanup_server)

    def cleanup_server(self):
        self.httpd.shutdown()
        self.httpd.server_close()
        self.ctrl.shutdown()
        self.thread.join(timeout=2)

    def call(self, method, path, data=None, *, token=True, origin=True, host=True):
        body = json.dumps(data or {}).encode('utf8')
        headers={'Content-Type':'application/json'}
        if token: headers['X-Local-Token']=self.ctrl.session_token
        if origin: headers['Origin']=f'http://127.0.0.1:{self.httpd.server_port}'
        if not host: headers['Host']='evil.invalid'
        c=http.client.HTTPConnection('127.0.0.1',self.httpd.server_port, timeout=5)
        c.request(method,path,body if method=='POST' else None,headers=headers)
        r=c.getresponse();x=r.read();code=r.status;c.close()
        return code,x

    def test_host_rejection(self):
        self.assertEqual(self.call('GET','/api/status',host=False)[0],403)

    def test_token_required_for_status_and_post(self):
        self.assertEqual(self.call('GET','/api/status',token=False)[0],403)
        self.assertEqual(self.call('POST','/api/stop',token=False)[0],403)
        self.assertEqual(self.call('POST','/api/stop',origin=False)[0],403)

    def test_ui_is_reachable_and_scrollable(self):
        code, page=self.call('GET','/')
        self.assertEqual(code,200)
        html=page.decode()
        self.assertIn('overflow-y:auto',html)
        self.assertIn('data-page="activity"',html)
        self.assertNotIn('__LOCAL_TOKEN__',html)

    def test_status_and_safe_connect_no_password(self):
        code,_=self.call('POST','/api/connect',dict(login=6001,server='Broker-Demo',password=''))
        self.assertEqual(code,200)
        for _ in range(25):
            if self.ctrl.status()['connected']:
                break
            time.sleep(.05)
        snap=self.ctrl.status()
        self.assertTrue(snap['connected'])
        self.assertTrue(snap['demo'])
        self.assertEqual(snap['account']['login'],6001)
        self.assertNotIn('password',str(snap).lower())
        self.assertEqual(self.mt.orders_sent,0)

    def test_auto_attach_demo_without_password(self):
        self.assertEqual(self.call('POST','/api/attach',{})[0],200)
        for _ in range(25):
            if self.ctrl.status()['connected']:
                break
            time.sleep(.05)
        self.assertTrue(self.ctrl.status()['connected'])
        self.assertEqual(self.mt.orders_sent,0)

    def test_auto_attach_rejects_real(self):
        self.mt.account.trade_mode=self.mt.ACCOUNT_TRADE_MODE_REAL
        self.assertEqual(self.call('POST','/api/attach',{})[0],200)
        time.sleep(.15)
        self.assertFalse(self.ctrl.status()['connected'])
        self.assertEqual(self.mt.orders_sent,0)

    def test_start_requires_demo_and_confirmation(self):
        self.ctrl._event('connected', dict(login=6001,server='Broker-Demo',currency='EUR',demo=True))
        self.assertEqual(self.call('POST','/api/start',{'symbols':'XAUUSD'})[0],409)
        self.assertEqual(self.mt.orders_sent,0)

    def test_ai_bailout_and_stop_cancels(self):
        self.ctrl._event('connected',dict(login=6001,server='Broker-Demo',currency='EUR',demo=True))
        self.ctrl.auth_state='connected'
        with patch('trading_ai_desktop.browser_server.subprocess.Popen') as p:
            proc=p.return_value
            def succeed(timeout):
                day = datetime.now(timezone.utc).date().isoformat()
                folder = self.ctrl.worker.store.file.parent / 'ai_reports'
                folder.mkdir(exist_ok=True)
                (folder / f'XAUUSD_{day}.json').write_text(json.dumps({
                    'market':'XAUUSD','proxy':'GC=F','provider':'chatgpt','approved':False,
                    'date_utc':day,'action':'HOLD','generated_at_epoch':time.time()}))
                return 0
            proc.wait.side_effect=succeed
            proc.returncode=0
            proc.poll.return_value=0
            code,_=self.call('POST','/api/ai/test',{'symbols':'XAUUSD'})
            self.assertEqual(code,200)
            for _ in range(30):
                if not self.ctrl.status()['ai_busy']:
                    break
                time.sleep(.05)
        snap=self.ctrl.status()
        self.assertEqual(snap['ai_stage'],'completed')
        self.assertEqual(snap['ai_results'][0]['action'],'HOLD')
        self.assertFalse(self.ctrl.worker.running)
        self.assertEqual(self.mt.orders_sent,0)

    def test_process_error_fails_closed(self):
        self.ctrl._event('connected',dict(login=6001,server='Broker-Demo',currency='EUR',demo=True))
        self.ctrl.auth_state='connected'
        with patch('trading_ai_desktop.browser_server.subprocess.Popen', side_effect=OSError('no exe')):
            self.assertTrue(self.ctrl.start_demo({'symbols':'XAUUSD','confirmation':'DEMO ONLY'})[0])
            for _ in range(30):
                if not self.ctrl.status()['ai_busy']:
                    break
                time.sleep(.05)
        snap=self.ctrl.status()
        self.assertEqual(snap['ai_stage'],'failed')
        self.assertFalse(snap['running'])
        self.assertEqual(self.mt.orders_sent,0)

    def test_stop_cancels_inflight_ai(self):
        self.ctrl._event('connected',dict(login=6001,server='Broker-Demo',currency='EUR',demo=True))
        self.ctrl.auth_state='connected'
        with patch('trading_ai_desktop.browser_server.subprocess.Popen') as p:
            proc=p.return_value
            def fake_wait(timeout):
                time.sleep(.15)
                return ('', '')
            proc.wait.side_effect=lambda timeout: (time.sleep(.15) or 0)
            proc.poll.return_value=None
            self.ctrl.ai_test({'symbols':'XAUUSD'})
            time.sleep(.025)
            self.ctrl.stop()
            time.sleep(.2)
            self.assertTrue(proc.terminate.called)
            self.assertEqual(self.ctrl.status()['ai_stage'],'stopped')
            self.assertFalse(self.ctrl.status()['running'])

if __name__=='__main__':unittest.main()
