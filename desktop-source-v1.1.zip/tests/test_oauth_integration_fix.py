"""ChatGPT callback != credential: verify, persist, fail-closed UX regressions."""
import importlib
import json
import tempfile
import time
import unittest
from pathlib import Path
from types import ModuleType
from unittest.mock import patch

from trading_ai_desktop import ai
from trading_ai_desktop.browser_server import Controller, AppServer
from test_desktop_core import DummyMT5
from run_browser import _ai_child

class OAuthFixTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.mt=DummyMT5()
        self.c=Controller(mt5=self.mt,data_dir=Path(self.tmp.name),auto_auth_check=False)
        self.addCleanup(self.c.shutdown)

    def wait_status(self):
        for _ in range(60):
            if not self.c.status()['ai_busy']:
                break
            time.sleep(.02)
        self.assertFalse(self.c.status()['ai_busy'])
        return self.c.status()

    def mock_proc(self, code):
        def create(*a,**kw):
            class P:
                returncode=code
                def wait(self,timeout): return code
                def poll(self): return code
                def terminate(self): pass
                def kill(self): pass
            return P()
        return create

    def test_browser_callback_no_token_is_not_connected(self):
        with patch('trading_ai_desktop.browser_server.subprocess.Popen',side_effect=self.mock_proc(34)):
            self.assertTrue(self.c.login_ai()[0])
            s=self.wait_status()
        self.assertEqual(s['auth_state'],'disconnected')
        self.assertEqual(s['ai_stage'],'auth_failed')
        self.assertIn('токен',s['auth_message'])
        self.assertEqual(self.mt.orders_sent,0)

    def test_valid_previous_session_detected_on_check_without_browser_login(self):
        with patch('trading_ai_desktop.browser_server.subprocess.Popen',side_effect=self.mock_proc(0)) as p:
            self.assertTrue(self.c.verify_auth()[0])
            s=self.wait_status()
        self.assertEqual(s['auth_state'],'connected')
        self.assertIn('потвърдена',s['auth_message'])
        self.assertIn('auth-check',p.call_args.args[0])
        self.assertNotIn('access_token',str(s))

    def test_auth_check_endpoint_does_not_expose_credentials(self):
        import http.client
        import threading
        server=AppServer(('127.0.0.1',0),self.c)
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        try:
            payload=b'{}'
            origin=f'http://127.0.0.1:{server.server_port}'
            headers={'Host':f'127.0.0.1:{server.server_port}', 'Origin':origin,
                     'X-Local-Token':self.c.session_token, 'Content-Type':'application/json'}
            with patch('trading_ai_desktop.browser_server.subprocess.Popen',side_effect=self.mock_proc(0)):
                http=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=3)
                http.request('POST','/api/ai/auth-check',payload,headers)
                response=http.getresponse();data=response.read();http.close()
                self.assertEqual(response.status,200)
                self.assertIn(b'\"ok\":true',data)
                snap=self.wait_status()
                self.assertEqual(snap['auth_state'],'connected')
                self.assertNotIn('token',json.dumps(snap).lower())
        finally:
            server.shutdown();server.server_close();thread.join(timeout=2)

    def test_no_auth_blocks_ai_and_demo_even_with_broker(self):
        self.c._event('connected',dict(login=15,server='Broker',currency='EUR',demo=True))
        self.assertFalse(self.c.ai_test({'symbols':'XAUUSD'})[0])
        self.assertFalse(self.c.start_demo({'symbols':'XAUUSD','confirmation':'DEMO ONLY'})[0])
        self.assertEqual(self.mt.orders_sent,0)

    def test_expired_session_fails_closed_without_duplicate_login(self):
        self.c.auth_state='connected'
        with patch('trading_ai_desktop.browser_server.subprocess.Popen',side_effect=self.mock_proc(10)):
            self.c.verify_auth();s=self.wait_status()
        self.assertEqual(s['auth_state'],'disconnected')
        self.c._event('connected',dict(login=15,server='Broker',currency='EUR',demo=True))
        self.assertFalse(self.c.start_demo({'symbols':'XAUUSD','confirmation':'DEMO ONLY'})[0])

    def test_upstream_persisted_token_required_even_without_email_claim(self):
        auth=ModuleType('tradingagents.llm_clients.chatgpt_auth')
        token='DO-NOT-EXPOSE-SECRET'
        auth.signed_in_as=lambda: None
        auth.credential=lambda:lambda:token
        root=ModuleType('tradingagents');root.__path__=[]
        llm=ModuleType('tradingagents.llm_clients');llm.__path__=[]
        llm.chatgpt_auth=auth
        with patch.dict('sys.modules',{'tradingagents':root,'tradingagents.llm_clients':llm,
                                        'tradingagents.llm_clients.chatgpt_auth':auth}):
            self.assertTrue(ai.verified_chatgpt_session())
            self.assertEqual(_ai_child(['auth-check']),0)
            auth.credential=lambda: (_ for _ in ()).throw(RuntimeError('no token'))
            self.assertEqual(_ai_child(['auth-check']),33)

    def test_oauth_provider_failure_is_not_confused_with_callback_completion(self):
        class ChatGPTAuthError(RuntimeError): pass
        with patch('trading_ai_desktop.ai.sign_in_chatgpt',side_effect=ChatGPTAuthError('Sensitive code data')):
            self.assertEqual(_ai_child(['login']),32)

    def test_unreachable_provider_returns_safe_code(self):
        class ChatGPTUnreachable(RuntimeError): pass
        with patch('trading_ai_desktop.ai.sign_in_chatgpt',side_effect=ChatGPTUnreachable('Sensitive token data')):
            self.assertEqual(_ai_child(['login']),31)

if __name__=='__main__':unittest.main()
