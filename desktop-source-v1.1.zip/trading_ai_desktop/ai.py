"""TauricResearch TradingAgents v0.7.1 integration for demo-only research gating.

Broker data execution remains in core.py; TradingAgents sees external research
proxies and never obtains broker login, passwords or order_send access.
"""
from __future__ import annotations
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Any
import json
import re
import time
from urllib.parse import urlparse
import webbrowser

# Research proxy != broker symbol. Exact whitelist is intentional.
RESEARCH_SYMBOLS = {
    'XAUUSD': 'GC=F', 'NAS100': '^NDX', 'EURUSD': 'EURUSD=X',
    'GBPUSD': 'GBPUSD=X', 'BTCUSD': 'BTC-USD',
}
ACTIONS = {'BUY', 'SELL', 'HOLD'}
MAX_REPORT_AGE_SECONDS = 21600  # Upstream is a daily research model, not tick signal.
AUTH_HOSTS = {'auth.openai.com', 'chatgpt.com', 'localhost', '127.0.0.1'}


def parse_action(value: Any) -> str:
    """Explicit machine action only, never a narrative or inferred sentiment."""
    if isinstance(value, dict):
        if set(value) != {'action'}:
            return 'UNRESOLVED'
        value = value['action']
    if not isinstance(value, str):
        return 'UNRESOLVED'
    raw = value.strip()
    if raw.upper() in ACTIONS:
        return raw.upper()
    try:
        obj = json.loads(raw)
    except (ValueError, TypeError):
        return 'UNRESOLVED'
    return parse_action(obj) if isinstance(obj, dict) else 'UNRESOLVED'


def ai_permission(symbol: str, direction: str, folder: Path,
                  *, now: float | None = None, today: str | None = None) -> bool:
    if symbol not in RESEARCH_SYMBOLS or direction not in {'BUY', 'SELL'}:
        return False
    now = time.time() if now is None else now
    today = today or datetime.fromtimestamp(now, timezone.utc).date().isoformat()
    try:
        report = json.loads((folder / f'{symbol}_{today}.json').read_text(encoding='utf8'))
        if not isinstance(report, dict) or report.get('status', 'SUCCESS') != 'SUCCESS':
            return False
        issued = float(report.get('generated_at_epoch', 0))
    except (OSError, ValueError, TypeError, json.JSONDecodeError, UnicodeError):
        return False
    return (report.get('market') == symbol and
            report.get('proxy') == RESEARCH_SYMBOLS[symbol] and
            report.get('date_utc') == today and
            report.get('action') == direction and
            report.get('approved') is False and
            report.get('provider') == 'chatgpt' and
            0 <= now - issued <= MAX_REPORT_AGE_SECONDS)


def tradingagents_config():
    """Bundled upstream framework with a ChatGPT-plan provider preset.

    No OpenAI API key, broker secret, or user-specific credential is embedded.
    User must authorize ChatGPT OAuth once in the official browser flow.
    """
    from tradingagents.default_config import DEFAULT_CONFIG
    cfg = DEFAULT_CONFIG.copy()
    cfg['llm_provider'] = 'chatgpt'
    cfg['quick_think_provider'] = 'chatgpt'
    cfg['deep_think_provider'] = 'chatgpt'
    cfg['backend_url'] = cfg['quick_think_backend_url'] = cfg['deep_think_backend_url'] = None
    cfg['llm_max_retries'] = 1
    cfg['max_debate_rounds'] = 1
    cfg['max_risk_discuss_rounds'] = 1
    cfg['output_language'] = 'English'
    return cfg


def tradingagents_installed() -> bool:
    try:
        from tradingagents.graph.trading_graph import TradingAgentsGraph  # noqa: F401
        from tradingagents.llm_clients import chatgpt_auth  # noqa: F401
        return True
    except (ImportError, ModuleNotFoundError):
        return False


def verified_chatgpt_session() -> bool:
    """Check the original upstream auth store and token without leaking its value.

    This reads the same ~/.tradingagents/chatgpt-auth.json that the upstream
    OAuth callback writes. A browser callback alone is NOT proof of sign-in.
    """
    from tradingagents.llm_clients import chatgpt_auth
    # The upstream OAuth flow can legitimately omit email claims. Credential
    # presence + a nonexpired/refreshable token are the correct evidence.
    credential = chatgpt_auth.credential()
    return bool(credential())


def _trusted_auth_url(message: str) -> str | None:
    for token in re.findall(r'https?://[^\s<>]+', message):
        url = token.rstrip(').,;\'"')
        parsed = urlparse(url)
        if parsed.hostname in AUTH_HOSTS:
            return url
    return None


def sign_in_chatgpt(notify: Callable[[str], None],
                    open_url: Callable[[str], Any] | None = None) -> str:
    """Official upstream subscription OAuth; no plaintext tokens in app logs."""
    from tradingagents.llm_clients import chatgpt_auth
    opened: set[str] = set()
    def on_line(message: str):
        url = _trusted_auth_url(str(message))
        if url and url not in opened:
            opened.add(url)
            (open_url or webbrowser.open)(url)
            notify('Отворих браузъра за потвърждение на ChatGPT. Продължи там.')
        else:
            notify('Изчаквам потвърждение в ChatGPT…')
    email = chatgpt_auth.sign_in(say=on_line)
    if not email:
        raise RuntimeError('ChatGPT login did not return a signed-in account')
    return 'ChatGPT е свързан успешно.'


def describe_decision(decision: Any) -> tuple[str, str, str]:
    action = parse_action(decision)
    if action in ACTIONS:
        # The pinned graph returns a rating string. Also support the explicit
        # action object accepted by earlier versions. Only show allowlisted data.
        raw = decision.strip() if isinstance(decision, str) and decision.strip().upper() == action else json.dumps({'action': action})
        return action, raw, ''
    if isinstance(decision, str):
        rating = decision.strip().upper()
        if rating == 'REVIEW':
            return action, 'REVIEW', 'TradingAgents не откри еднозначна крайна оценка (REVIEW).'
        if rating in {'OVERWEIGHT', 'UNDERWEIGHT'}:
            return action, decision.strip(), 'Оценката за тегло в портфейл няма еднозначно съответствие с BUY, SELL или HOLD.'
        if not rating:
            return action, '', 'TradingAgents върна празна оценка.'
    if decision is None:
        return action, 'null', 'TradingAgents не върна оценка.'
    return action, '[скрито]', 'TradingAgents върна оценка извън очаквания формат. Неструктурираният текст е скрит.'


def write_json(target: Path, record: dict):
    target.parent.mkdir(parents=True, exist_ok=True)
    temp = target.with_suffix('.tmp')
    temp.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding='utf-8')
    # Windows can reject replacing a file during the brief UI progress read.
    for attempt in range(3):
        try:
            temp.replace(target)
            return
        except PermissionError:
            if attempt == 2:
                raise
            time.sleep(0.025)


def research(symbol: str, folder: Path, *, graph_factory=None,
             now: float | None = None, progress=None) -> dict:
    """Run the *actual* TradingAgents graph, with bounded output and failed-closed action.

    A research BUY/SELL is a direction veto for a separate broker-derived M5
    strategy, not a confirmed intraday edge nor an executable order.
    """
    if symbol not in RESEARCH_SYMBOLS:
        raise ValueError(f'Няма проверено research съответствие за символа {symbol}')
    started_at = time.time() if now is None else now
    day = datetime.fromtimestamp(started_at, timezone.utc).date().isoformat()
    if progress:
        progress('Зареждане на TradingAgents')
    from tradingagents.graph.trading_graph import TradingAgentsGraph
    cfg = tradingagents_config()
    factory = graph_factory or TradingAgentsGraph
    kwargs = {}
    if progress:
        from langchain_core.callbacks import BaseCallbackHandler

        class ModelProgress(BaseCallbackHandler):
            def on_chat_model_start(self, *args, **kwargs):
                progress('Заявка към ChatGPT')

            def on_llm_end(self, *args, **kwargs):
                progress('Получен отговор от ChatGPT')

            def on_llm_error(self, *args, **kwargs):
                progress('Грешка при заявка към ChatGPT')

        kwargs['callbacks'] = [ModelProgress()]
    graph = factory(debug=False, config=cfg, **kwargs)
    if progress:
        progress('Пазарни данни и анализ в TradingAgents')
    _state, decision = graph.propagate(RESEARCH_SYMBOLS[symbol], day)
    if progress:
        progress('Проверка на крайната оценка')
    action, raw, reason = describe_decision(decision)
    finished_at = time.time() if now is None else now
    record = {
        'market': symbol,
        'proxy': RESEARCH_SYMBOLS[symbol],
        'date_utc': day,
        'generated_at_epoch': finished_at,
        'provider': 'chatgpt',
        'action': action,
        'status': 'SUCCESS' if action in ACTIONS else 'UNRESOLVED',
        'reason': reason,
        'approved': False,
        'model_warning': 'Research-only proxy; NOT executable MT5 CFD prices; AI cannot bypass risk checks',
        'raw_decision': raw,
    }
    write_json(folder / f'{symbol}_{day}.json', record)
    return record
