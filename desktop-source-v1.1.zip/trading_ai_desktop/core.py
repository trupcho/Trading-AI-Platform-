"""Local MT5 execution engine. Demo orders only until independently validated.

All MetaTrader5 API calls are on one dedicated worker thread. Do not expose
this code as a public HTTP server or leave account passwords in configuration.
"""
from __future__ import annotations

from dataclasses import dataclass
from contextlib import contextmanager, closing
from datetime import datetime, timezone, timedelta
from decimal import Decimal
from pathlib import Path
from queue import Empty, Queue
import math
import os
import sqlite3
import threading
import time
from typing import Any, Callable
from types import SimpleNamespace

D = lambda x: Decimal(str(x))
MAGIC = 7261108
CAPITAL_CAP = D('100')
MAX_RISK_PCT = D('0.0025')
MAX_DAY_LOSS_PCT = D('0.01')
MAX_MARGIN_PCT = D('0.35')


@dataclass
class Connection:
    login: int
    server: str
    password: str
    terminal_path: str = ''


@dataclass(frozen=True)
class Signal:
    direction: str  # BUY | SELL | WAIT
    reason: str
    atr: float = 0.0
    bar_time: int = 0


def ema(values: list[float], period: int) -> list[float]:
    if len(values) < period + 3:
        raise ValueError('insufficient history')
    alpha = 2.0 / (period + 1)
    result = [values[0]]
    for x in values[1:]:
        result.append(result[-1] * (1 - alpha) + alpha * x)
    return result


def rsi(values: list[float], period: int = 14) -> float:
    if len(values) < period + 1:
        raise ValueError('insufficient history')
    changes = [values[i] - values[i - 1] for i in range(1, len(values))]
    gains = [max(x, 0) for x in changes[:period]]
    losses = [max(-x, 0) for x in changes[:period]]
    avg_gain, avg_loss = sum(gains) / period, sum(losses) / period
    for delta in changes[period:]:
        avg_gain = (avg_gain * (period - 1) + max(delta, 0)) / period
        avg_loss = (avg_loss * (period - 1) + max(-delta, 0)) / period
    if avg_loss == 0:
        return 100.0 if avg_gain else 50.0
    return 100 - (100 / (1 + avg_gain / avg_loss))


def analyze_bars(bars: list[dict[str, Any]], timeframe: str = 'M5') -> Signal:
    """Strictly CLOSED-bar signal. Never assumes profitability.

    Demo strategy: EMA9/EMA21 crossover + EMA50 trend and RSI14 filters;
    ATR14 approximates the stop distance. Market clock is broker-controlled.
    """
    if len(bars) < 80:
        return Signal('WAIT', 'Няма достатъчно исторически свещи')
    try:
        closes = [float(b['close']) for b in bars]
        highs = [float(b['high']) for b in bars]
        lows = [float(b['low']) for b in bars]
        bar_t = int(bars[-1]['time'])
        if not all(math.isfinite(x) and x > 0 for x in closes + highs + lows):
            raise ValueError('not finite')
        f, s, trend = ema(closes, 9), ema(closes, 21), ema(closes, 50)
        r = rsi(closes)
        tr = [max(highs[i] - lows[i], abs(highs[i] - closes[i - 1]),
                  abs(lows[i] - closes[i - 1])) for i in range(1, len(bars))]
        atr = sum(tr[-14:]) / 14
        if atr <= 0:
            return Signal('WAIT', 'ATR е нула', bar_time=bar_t)
        if f[-2] <= s[-2] and f[-1] > s[-1] and closes[-1] > trend[-1] and 52 <= r <= 72:
            return Signal('BUY', f'EMA crossover + RSI {r:.1f}', atr, bar_t)
        if f[-2] >= s[-2] and f[-1] < s[-1] and closes[-1] < trend[-1] and 28 <= r <= 48:
            return Signal('SELL', f'EMA crossover + RSI {r:.1f}', atr, bar_t)
        return Signal('WAIT', f'Няма сигнал · RSI {r:.1f}', atr, bar_t)
    except (ValueError, TypeError, KeyError, OverflowError, IndexError):
        return Signal('WAIT', 'Невалидни пазарни данни')


class AuditStore:
    """Local durable records; no credentials are written to disk."""
    def __init__(self, folder: Path):
        folder.mkdir(parents=True, exist_ok=True)
        self.file = folder / 'audit.sqlite3'
        self.lock = threading.Lock()
        with self.open() as db:
            db.execute('CREATE TABLE IF NOT EXISTS baselines ('
                       'account TEXT, day TEXT, equity TEXT, PRIMARY KEY(account,day))')
            db.execute('CREATE TABLE IF NOT EXISTS orders ('
                       'key TEXT PRIMARY KEY, account TEXT, state TEXT, timestamp TEXT, detail TEXT)')
            db.execute('CREATE TABLE IF NOT EXISTS bars ('
                       'account TEXT, symbol TEXT, bar_time INTEGER, PRIMARY KEY(account,symbol,bar_time))')

    @contextmanager
    def open(self):
        with closing(sqlite3.connect(self.file, timeout=15)) as db:
            with db:
                yield db

    def baseline(self, account: str, equity: Any, day: str) -> Decimal:
        with self.lock, self.open() as db:
            db.execute('INSERT OR IGNORE INTO baselines VALUES (?,?,?)', (account, day, str(equity)))
            return D(db.execute('SELECT equity FROM baselines WHERE account=? AND day=?',
                                (account, day)).fetchone()[0])

    def reserve_bar(self, account: str, symbol: str, bar_time: int) -> bool:
        with self.lock, self.open() as db:
            try:
                db.execute('INSERT INTO bars VALUES (?,?,?)', (account, symbol, bar_time))
                return True
            except sqlite3.IntegrityError:
                return False

    def reserve_order(self, key: str, account: str) -> bool:
        with self.lock, self.open() as db:
            db.execute('BEGIN IMMEDIATE')
            prior = db.execute("SELECT key FROM orders WHERE account=? AND state IN ('SENDING','UNKNOWN') LIMIT 1",
                               (account,)).fetchone()
            if prior:
                db.rollback()
                return False
            try:
                db.execute('INSERT INTO orders VALUES (?,?,?,?,?)',
                           (key, account, 'SENDING', datetime.now(timezone.utc).isoformat(), ''))
                db.commit()
                return True
            except sqlite3.IntegrityError:
                db.rollback()
                return False

    def finish(self, key: str, state: str, detail: str):
        with self.lock, self.open() as db:
            db.execute('UPDATE orders SET state=?, detail=? WHERE key=?',
                       (state, detail[:200], key))

    def recent_submission(self, account: str, wait_seconds: int = 300) -> bool:
        """Fail closed after confirmed/unknown sends, including app restarts."""
        with self.lock, self.open() as db:
            rows = db.execute("SELECT timestamp FROM orders WHERE account=? "
                              "AND state IN ('DONE','UNKNOWN','SENDING') ORDER BY timestamp DESC LIMIT 3",
                              (account,)).fetchall()
        now = datetime.now(timezone.utc)
        return any(0 <= (now - datetime.fromisoformat(t)).total_seconds() < wait_seconds for (t,) in rows)

    def unresolved(self, account: str) -> int:
        with self.lock, self.open() as db:
            return db.execute("SELECT count(*) FROM orders WHERE account=? AND state IN ('SENDING','UNKNOWN')",
                              (account,)).fetchone()[0]


class TradingWorker:
    """MT5 connection and monitoring on one worker thread."""
    def __init__(self, report: Callable[[str, dict], None], mt5: Any = None,
                 data_dir: Path | None = None):
        self.report = report
        self.mt5 = mt5
        self.queue: Queue = Queue()
        self.thread: threading.Thread | None = None
        self.connected = False
        self.running = False
        self.is_demo = False
        self.account = None
        self.symbols = ['XAUUSD']
        self.poll_seconds = 8
        self.require_ai = False
        self.next_poll = 0.0
        self.store = AuditStore(data_dir or Path.home() / '.trading_ai_desktop')
        self.ai_report_dir = self.store.file.parent / 'ai_reports'
        self._log_repeat: set[str] = set()
        self.stop_requested = threading.Event()

    def start_thread(self):
        if self.thread and self.thread.is_alive():
            return
        self.thread = threading.Thread(target=self._loop, name='TradingAI-MT5', daemon=True)
        self.thread.start()

    def send(self, command: str, **kwargs):
        self.queue.put((command, kwargs))

    def request_stop(self):
        """Immediate stop signal checked before any broker submission."""
        self.stop_requested.set()
        self.send('stop')

    def _event(self, kind: str, **info):
        self.report(kind, info)

    def _log(self, message: str):
        self._event('log', message=message)

    def _loop(self):
        while True:
            try:
                cmd, data = self.queue.get(timeout=0.25)
            except Empty:
                cmd, data = None, {}
            try:
                if cmd == 'connect':
                    self._connect(data['credentials'])
                elif cmd == 'start':
                    self._start(data['symbols'], ai_report_dir=data.get('ai_report_dir'),
                                cancel=data.get('cancel'))
                    self._event('start_result', running=self.running)
                elif cmd == 'stop':
                    self.stop_requested.set()
                    self.running = False
                    self._event('mode', value='STOP')
                    self._log('Автоматичните DEMO поръчки са спрени. Отворените позиции остават при брокера.')
                elif cmd == 'disconnect':
                    self._disconnect()
                elif cmd == 'shutdown':
                    self._disconnect()
                    return
                elif cmd == 'scan' and self.connected:
                    self._refresh()
                elif cmd == 'diagnose' and self.connected:
                    self._diagnose(data.get('symbols', []))
                elif cmd == 'ai_required':
                    self.require_ai = bool(data['value'])
                    self._log('TradingAgents филтър: ' + ('ON (без валиден отчет нови сделки се отказват).' if self.require_ai else 'OFF (локален механичен агент).'))
                if self.connected and time.monotonic() >= self.next_poll:
                    self._refresh()
                    self.next_poll = time.monotonic() + self.poll_seconds
            except Exception as e:
                # Never print passwords or connection data in errors.
                self.running = False
                self._event('mode', value='STOP')
                self._log('Спряно поради грешка в терминала: ' + type(e).__name__)

    def _connect(self, c: Connection):
        self._disconnect()
        if self.mt5 is None:
            try:
                import MetaTrader5 as module
                self.mt5 = module
            except ImportError:
                c.password = ''
                self._log('Липсва MetaTrader5 Python модул. Стартирай INSTALL_AND_RUN.bat.')
                return
        mt = self.mt5
        attach_current = c.login == 0 and not c.server.strip() and not c.password
        if not attach_current and (c.login <= 0 or not c.server.strip()):
            self._log('Попълни валиден MT5 Login номер и Server.')
            return
        # Password optional when MT5 is already logged in on this computer.
        # Never auto-switch accounts: the identity is checked immediately below.
        if c.password:
            kw = dict(login=int(c.login), password=c.password, server=c.server.strip(), timeout=20000)
        else:
            kw = dict(timeout=20000)
        try:
            connected = mt.initialize(c.terminal_path.strip(), **kw) if c.terminal_path.strip() else mt.initialize(**kw)
        finally:
            kw['password'] = ''
            c.password = ''
        if not connected:
            self._log('MT5 не установи връзка. Провери данните и дали терминалът е инсталиран.')
            return
        account = mt.account_info()
        if (account is None or
                (attach_current and account.trade_mode != mt.ACCOUNT_TRADE_MODE_DEMO) or
                (not attach_current and (int(account.login) != c.login or account.server != c.server.strip()))):
            self._log('MT5 сметката не съвпада или автоматичното откриване не намери DEMO. Връзката е отказана.')
            mt.shutdown()
            return
        # Copy immutable connection identity rather than keeping the broker's
        # mutable account_info object. Any later account change must fail closed.
        self.account = SimpleNamespace(login=int(account.login),
                                       server=str(account.server),
                                       trade_mode=int(account.trade_mode))
        self.connected = True
        self.is_demo = account.trade_mode == mt.ACCOUNT_TRADE_MODE_DEMO
        self._event('connected', login=int(account.login), server=str(account.server),
                    currency=str(account.currency), demo=self.is_demo)
        self._log('Свързано към ' + ('DEMO' if self.is_demo else 'REAL') +
                  ' MT5 сметка. ' + ('DEMO заявки са допустими след Start.' if self.is_demo else
                                    'REAL сметки са само за наблюдение в тази версия.'))
        self.next_poll = 0

    def _disconnect(self):
        self.running = False
        if self.connected and self.mt5 is not None:
            try:
                self.mt5.shutdown()
            except Exception:
                pass
        self.connected = False
        self.is_demo = False
        self.account = None
        self._event('mode', value='STOP')
        self._event('disconnected')

    def _start(self, symbols: list[str], *, ai_report_dir=None, cancel=None):
        self.stop_requested.clear()
        if cancel is not None and cancel.is_set():
            self.stop_requested.set()
            return
        if not self.connected:
            self._log('Първо се свържи с MT5.')
            return
        if not self.is_demo:
            self._log('Реалната сметка е само за наблюдение, докато не преминем broker/live проверките.')
            return
        clean = [s.strip() for s in symbols if s.strip()]
        if not clean or len(clean) > 4 or any(not s.replace('.', '').replace('_', '').replace('-', '').isalnum() or len(s) > 32 for s in clean):
            self._log('Посочи до 4 валидни MT5 символа, разделени със запетая.')
            return
        self.symbols = list(dict.fromkeys(clean))
        self.ai_report_dir = ai_report_dir or self.store.file.parent / 'ai_reports'
        self.running = True
        self.next_poll = 0
        self._event('mode', value='DEMO RUN')
        self._log('DEMO автоматизацията е включена: ' + ', '.join(self.symbols))

    def _refresh(self):
        mt = self.mt5
        account = mt.account_info()
        if account is None or account.login != self.account.login or account.server != self.account.server:
            self.running = False
            self._event('mode', value='STOP')
            self._log('Сметката е сменена или връзката е прекъсната. Автоматизацията е спряна.')
            return
        if (account.trade_mode == mt.ACCOUNT_TRADE_MODE_DEMO) != self.is_demo:
            self.running = False
            self._log('Режимът на сметката е променен. Автоматизацията е спряна.')
            return
        positions = mt.positions_get()
        orders = mt.orders_get()
        if positions is None or orders is None:
            self.running = False
            self._log('MT5 не върна всички позиции/поръчки. Автоматизацията е спряна.')
            return
        base = self.store.baseline(str(account.login), account.equity,
                                   datetime.now(timezone.utc).date().isoformat())
        cap = min(D(account.equity), CAPITAL_CAP)
        risk_budget = cap * MAX_RISK_PCT
        if D(account.equity) <= base - min(base, CAPITAL_CAP) * MAX_DAY_LOSS_PCT:
            self.running = False
            self._event('mode', value='HALT')
            self._log('Дневният стоп е достигнат. Новите поръчки са блокирани.')
        self._event('status', balance=float(account.balance), equity=float(account.equity),
                    profit=float(account.profit), currency=str(account.currency),
                    positions=len(positions), pending=len(orders), risk=float(risk_budget),
                    mode='DEMO' if self.is_demo else 'REAL',
                    running=self.running, baseline=float(base))
        if not self.running or not self.is_demo or self.stop_requested.is_set():
            return
        if (self.store.file.parent / 'STOP_TRADING').exists():
            self.running = False
            self._log('Файлът STOP_TRADING е открит. Автоматизацията е спряна.')
            return
        if account.currency != 'EUR':
            self.running = False
            self._log('Сметката не е в EUR. За този €100 пилот автоматизацията е спряна.')
            return
        if (len(positions) != 0 or len(orders) != 0 or
                self.store.unresolved(str(account.login)) or
                self.store.recent_submission(str(account.login))):
            return
        for symbol in self.symbols:
            if not self.running:
                break
            self._evaluate_symbol(symbol, account, base)

    def _diagnose(self, symbols: list[str]):
        """Read-only broker contract checks; never calls order_send/order_check."""
        mt = self.mt5
        account = mt.account_info()
        if (not self.connected or account is None or self.account is None
                or account.login != self.account.login or account.server != self.account.server
                or account.trade_mode != self.account.trade_mode):
            self.running = False
            self._event('diagnostics', account_type='DISCONNECTED', currency='—', symbols=[])
            self._log('Свързването е прекъснато или сметката е променена.')
            return
        results = []
        clean = list(dict.fromkeys(str(x).strip() for x in symbols if str(x).strip()))[:4]
        for sym in clean:
            item = {'symbol': sym, 'state': 'Неизвестен символ'}
            try:
                broker_symbol, info = self._broker_contract(sym, account)
                if info is None:
                    results.append(item)
                    continue
                item['broker_symbol'] = broker_symbol
                if not info.visible and not mt.symbol_select(broker_symbol, True):
                    item['state'] = 'Символът не е достъпен'
                    results.append(item)
                    continue
                tick = mt.symbol_info_tick(broker_symbol)
                if tick is None or float(tick.ask) <= float(tick.bid) or float(tick.bid) <= 0:
                    item['state'] = 'Няма актуална валидна котировка'
                    results.append(item)
                    continue
                if abs(int(time.time())-int(tick.time)) > 120:
                    item['state'] = 'Котировката е стара или пазарът е затворен'
                    results.append(item)
                    continue
                minlot = float(info.volume_min)
                margin = mt.order_calc_margin(mt.ORDER_TYPE_BUY, broker_symbol, minlot, float(tick.ask))
                item.update(state='Проверени брокерски данни (само информация)',
                            min_lot=f'{minlot:.6g}',
                            spread=f'{float(tick.ask) - float(tick.bid):.6g}',
                            margin_eur=(f'{float(margin):.2f} {account.currency}' if margin is not None else 'N/A'))
            except (ValueError, TypeError, AttributeError, OverflowError):
                item['state'] = 'Грешка в данните на брокера'
            results.append(item)
        self._event('diagnostics', account_type='DEMO' if self.is_demo else 'REAL / MONITOR ONLY',
                    currency=str(account.currency), symbols=results)

    def _broker_contract(self, symbol, account):
        info = self.mt5.symbol_info(symbol)
        broker = f"{account.server} {getattr(account, 'company', '')}".lower()
        alias = {'XAUUSD': 'GOLD.pro', 'EURUSD': 'EURUSD.pro'}.get(symbol)
        if alias and 'oanda' in broker and getattr(info, 'trade_mode', None) != self.mt5.SYMBOL_TRADE_MODE_FULL:
            alias_info = self.mt5.symbol_info(alias)
            if getattr(alias_info, 'trade_mode', None) == self.mt5.SYMBOL_TRADE_MODE_FULL:
                return alias, alias_info
        return symbol, info

    def _evaluate_symbol(self, symbol: str, account: Any, base: Decimal):
        if self.stop_requested.is_set():
            return
        mt = self.mt5
        research_symbol = symbol
        symbol, info = self._broker_contract(symbol, account)
        if info is None:
            if symbol not in self._log_repeat:
                self._log('Брокерът няма символ ' + symbol + '. Провери името в Market Watch.')
                self._log_repeat.add(symbol)
            return
        if not info.visible and not mt.symbol_select(symbol, True):
            return
        if getattr(info, 'trade_mode', None) != mt.SYMBOL_TRADE_MODE_FULL:
            return
        bars = mt.copy_rates_from_pos(symbol, mt.TIMEFRAME_M5, 1, 180)
        if bars is None or len(bars) < 80:
            return
        records = [dict(time=int(b['time']), open=float(b['open']), high=float(b['high']),
                        low=float(b['low']), close=float(b['close'])) for b in bars]
        records.sort(key=lambda b: b['time'])
        signal = analyze_bars(records)
        if signal.direction == 'WAIT':
            return
        if self.require_ai:
            from .ai import ai_permission
            if not ai_permission(research_symbol, signal.direction, self.ai_report_dir):
                return
        key = f'{account.login}:{symbol}'
        if not self.store.reserve_bar(str(account.login), symbol, signal.bar_time):
            return
        tick = mt.symbol_info_tick(symbol)
        now = int(time.time())
        if tick is None or tick.time > now + 5 or now - tick.time > 30:
            return
        if not getattr(mt.terminal_info(), 'trade_allowed', False) or not getattr(account, 'trade_allowed', False):
            self._log('В MT5 не са разрешени автоматизирани сделки.')
            return
        if (account.trade_mode != mt.ACCOUNT_TRADE_MODE_DEMO or account.login != self.account.login or
                account.server != self.account.server):
            self.running = False
            return
        if mt.positions_get() is None or mt.orders_get() is None or len(mt.positions_get()) or len(mt.orders_get()):
            return
        buy = signal.direction == 'BUY'
        entry = D(tick.ask if buy else tick.bid)
        bid, ask = D(tick.bid), D(tick.ask)
        spread = ask - bid
        point = D(info.point)
        tick_size = D(getattr(info, 'trade_tick_size', None) or info.point)
        stop_min = D(info.trade_stops_level) * point + spread
        atr = D(signal.atr)
        stop_dist = max(atr * D('2.0'), stop_min * D('1.5'))
        target_dist = stop_dist * D('1.5')
        if any(not x.is_finite() or x <= 0 for x in (entry, tick_size, spread, stop_dist)):
            return
        if spread > atr * D('0.12'):
            return
        from decimal import ROUND_CEILING, ROUND_FLOOR
        stop_raw = entry - stop_dist if buy else entry + stop_dist
        target_raw = entry + target_dist if buy else entry - target_dist
        stop = (stop_raw / tick_size).to_integral_value(rounding=ROUND_FLOOR if buy else ROUND_CEILING) * tick_size
        target = (target_raw / tick_size).to_integral_value(rounding=ROUND_CEILING if buy else ROUND_FLOOR) * tick_size
        if stop <= 0 or target <= 0:
            return
        if buy and (stop >= bid - D(info.trade_stops_level) * point or target <= bid + D(info.trade_stops_level) * point):
            return
        if not buy and (stop <= ask + D(info.trade_stops_level) * point or target >= ask - D(info.trade_stops_level) * point):
            return
        lot = D(info.volume_min)
        vol_step = D(info.volume_step)
        if lot <= 0 or vol_step <= 0 or lot > D(info.volume_max):
            return
        # Conservative broker-minimum-only volume; do not force invalid lot.
        if (lot / vol_step) != (lot / vol_step).to_integral_value():
            return
        side = mt.ORDER_TYPE_BUY if buy else mt.ORDER_TYPE_SELL
        margin = mt.order_calc_margin(side, symbol, float(lot), float(entry))
        pnl = mt.order_calc_profit(side, symbol, float(lot), float(entry), float(stop))
        if margin is None or pnl is None or not math.isfinite(margin) or not math.isfinite(pnl):
            return
        risk_budget = min(D(account.equity), CAPITAL_CAP) * MAX_RISK_PCT
        buffer = max(D('0.05'), risk_budget * D('0.20'))  # illustrative, NOT broker verified
        loss = max(D('0'), -D(pnl)) + buffer
        if loss > risk_budget or D(margin) > min(D(account.equity), CAPITAL_CAP) * MAX_MARGIN_PCT:
            if symbol not in self._log_repeat:
                self._log(f'{symbol}: минималният лот не се побира в риска €{risk_budget:.2f} или маржин лимита.')
                self._log_repeat.add(symbol)
            return
        filling = getattr(info, 'filling_mode', 0)
        if filling & mt.SYMBOL_FILLING_IOC:
            fill = mt.ORDER_FILLING_IOC
        elif filling & mt.SYMBOL_FILLING_FOK:
            fill = mt.ORDER_FILLING_FOK
        else:
            return
        request = dict(action=mt.TRADE_ACTION_DEAL, symbol=symbol, volume=float(lot), type=side,
                       price=float(entry), sl=float(stop), tp=float(target), deviation=10,
                       magic=MAGIC, comment='TradingAI-Demo', type_time=mt.ORDER_TIME_GTC,
                       type_filling=fill)
        chk = mt.order_check(request)
        if chk is None or getattr(chk, 'retcode', -1) != 0:
            self._log(symbol + ': брокерът отказа предварителната проверка на заявката.')
            return
        order_id = f'{account.login}-{symbol}-{signal.bar_time}'
        if not self.store.reserve_order(order_id, str(account.login)):
            self._log('Има неизяснена поръчка. Автоматизацията е спряна.')
            self.running = False
            return
        # Check the account type once more immediately before broker submission.
        fresh_account = mt.account_info()
        if (fresh_account is None or fresh_account.login != account.login or
                fresh_account.server != account.server or
                fresh_account.trade_mode != mt.ACCOUNT_TRADE_MODE_DEMO):
            self.store.finish(order_id, 'UNKNOWN', 'Account changed during preflight')
            self.running = False
            return
        if self.stop_requested.is_set():
            self.store.finish(order_id, 'UNKNOWN', 'Stop requested during final preflight; reconcile manually')
            self.running = False
            return
        try:
            result = mt.order_send(request)
            if result is not None and result.retcode == mt.TRADE_RETCODE_DONE:
                self.store.finish(order_id, 'DONE', 'Broker confirmed')
                self._log(f'DEMO {signal.direction} {symbol} · {lot} лота · SL {stop}, TP {target}')
            else:
                self.store.finish(order_id, 'UNKNOWN', 'Order result requires broker reconciliation')
                self.running = False
                self._log('Неясен резултат от брокера. Ботът спря за проверка.')
        except Exception:
            self.store.finish(order_id, 'UNKNOWN', 'Terminal exception; reconcile manually')
            self.running = False
            self._log('Неизвестен резултат от ордер. Ботът спря.')
