"""Private, local-only browser dashboard for a demo-only MetaTrader 5 engine.

The HTTP endpoint is bound exclusively to 127.0.0.1. Any order capable action
requires a CSRF token, exact Origin and an explicit DEMO acknowledgement.
The browser is a presentation surface; all MT5 API calls remain on the worker.
"""
from __future__ import annotations

from collections import deque
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import secrets
import subprocess
import sys
import threading
import time
from typing import Any
from urllib.parse import urlparse
import webbrowser

from .core import Connection, TradingWorker, CAPITAL_CAP
from .ai import ACTIONS, RESEARCH_SYMBOLS

HOST = '127.0.0.1'
PORT = 8766
MAX_BODY = 8192
AI_TIMEOUT_SECONDS = 420
ROOT = Path(__file__).resolve().parent


def ai_child_command(kind: str, *args: str) -> list[str]:
    if getattr(sys, 'frozen', False):
        return [sys.executable, '--ai-child', kind, *args]
    return [sys.executable, str(ROOT.parent / 'run_browser.py'), '--ai-child', kind, *args]


class Controller:
    """Thread-safe UI state; requests never invoke blocking MT5 or AI operations."""
    def __init__(self, *, mt5: Any = None, data_dir: Path | None = None, auto_auth_check: bool = True):
        self.lock = threading.RLock()
        self._events = deque(maxlen=250)
        self.worker = TradingWorker(self._event, mt5=mt5, data_dir=data_dir)
        self.worker.require_ai = True
        self.worker.start_thread()
        self.session_token = secrets.token_urlsafe(32)
        self.connected = False
        self.demo = False
        self.running = False
        self._start_pending = False
        self.ai_busy = False
        self.auth_state = 'unknown'
        self.auth_message = 'ChatGPT сесията още не е проверена.'
        self.ai_stage = 'idle'
        self.ai_status = 'Не е стартиран анализ'
        self.ai_symbols: list[str] = []
        self.ai_results: list[dict] = []
        self._generation = 0
        self._ai_process: subprocess.Popen | None = None
        self._ai_cancel = threading.Event()
        self.account = {}
        self.metrics = {}
        self.diagnostics = []
        self.terminal_path = ''
        self._closed = False
        self._log('Пуснат локален браузърен интерфейс. Само DEMO поръчки; REAL е заключен.')
        if auto_auth_check:
            self.verify_auth()

    def _log(self, message: str):
        with self.lock:
            self._events.appendleft({'time': datetime.now().strftime('%H:%M:%S'), 'message': str(message)[:600]})

    def _event(self, kind: str, data: dict):
        with self.lock:
            if kind == 'log':
                self._log(data['message'])
            elif kind == 'connected':
                self.connected = True
                self.demo = bool(data['demo'])
                self.running = False
                self.account = {k: data[k] for k in ('login', 'server', 'currency')}
                self.account['demo'] = self.demo
                if not self.ai_busy:
                    self.ai_stage = 'idle'
                    self.ai_status = 'Свързано с MT5 · AI не е стартиран'
                    self.ai_results = []
                self.diagnostics = []
                self._log('MT5: ' + ('DEMO' if self.demo else 'REAL — само наблюдение') + ' сметка е проверена.')
            elif kind == 'disconnected':
                self.connected = self.demo = self.running = False
                self.account = {}
                self.metrics = {}
                self.diagnostics = []
            elif kind == 'status':
                self.metrics = {k: data[k] for k in ('balance', 'equity', 'profit', 'currency', 'positions', 'pending', 'risk', 'mode', 'running', 'baseline') if k in data}
                self.running = bool(data.get('running', False))
            elif kind == 'mode':
                self.running = data['value'] == 'DEMO RUN'
                if data['value'] != 'DEMO RUN':
                    self._start_pending = False
            elif kind == 'start_result':
                self._start_pending = False
                self.running = data['running']
            elif kind == 'diagnostics':
                self.diagnostics = data.get('symbols', [])
                self._log('Проверих MT5 спецификациите без изпращане на поръчки.')

    def status(self) -> dict:
        with self.lock:
            return {
                'connected': self.connected, 'demo': self.demo, 'running': self.running or self._start_pending,
                'account': dict(self.account), 'metrics': dict(self.metrics),
                'ai_busy': self.ai_busy, 'ai_stage': self.ai_stage,
                'auth_state': self.auth_state, 'auth_message': self.auth_message,
                'ai_status': self.ai_status, 'ai_results': list(self.ai_results),
                'logs': list(self._events), 'diagnostics': list(self.diagnostics),
                'capital_cap': float(CAPITAL_CAP), 'terminal_path': self.terminal_path,
                'stop_note': 'STOP спира нови поръчки, не затваря отворените позиции.',
            }

    def connect(self, data: dict) -> tuple[bool, str]:
        with self.lock:
            if self.ai_busy or self.running or self._start_pending:
                return False, 'Първо спри анализа или демо търговията.'
            try:
                login = int(str(data.get('login', '')).strip())
            except ValueError:
                return False, 'Въведи валиден MT5 Login номер.'
            server = str(data.get('server') or '').strip()
            if login <= 0 or not server or len(server) > 128:
                return False, 'Липсва валиден Login или Server.'
            path = str(data.get('terminal_path') or '').strip()
            if len(path) > 500:
                return False, 'Пътят към MT5 е невалиден.'
            password = str(data.get('password') or '')
            if len(password) > 256:
                return False, 'Паролата е твърде дълга.'
            self._generation += 1
            self.worker.send('connect', credentials=Connection(login, server, password, path))
            self.terminal_path = path
            self._log('Свързване с MT5. Данните се проверяват на компютъра.')
            return True, 'Свързването е заявено; резултатът ще се появи в таблото.'

    def attach_current(self, data: dict) -> tuple[bool, str]:
        """Attach read-only to currently signed-in DEMO MT5, without credentials."""
        with self.lock:
            if self.ai_busy or self.running or self._start_pending:
                return False, 'Първо спри анализа или DEMO търговията.'
            path = str(data.get('terminal_path') or '').strip()
            if len(path) > 500:
                return False, 'Пътят към MT5 е невалиден.'
            self._generation += 1
            self.worker.send('connect', credentials=Connection(0, '', '', path))
            self.terminal_path = path
            self._log('Опит за свързване с вече отворен MT5 DEMO терминал — без парола.')
            return True, 'Търся активна MT5 DEMO сесия на компютъра.'

    def diagnose(self, data: dict) -> tuple[bool, str]:
        with self.lock:
            if not self.connected:
                return False, 'Първо свържи MT5.'
            symbols = self._symbols(data)
            if not symbols:
                return False, 'Избери до 4 точни брокерски символа.'
            self.worker.send('diagnose', symbols=symbols)
            return True, 'Проверката се изпълнява без ордери.'

    @staticmethod
    def _symbols(data: dict) -> list[str]:
        raw = data.get('symbols', 'XAUUSD, EURUSD')
        if not isinstance(raw, str) or len(raw) > 150:
            return []
        symbols = list(dict.fromkeys(s.strip().upper() for s in raw.split(',') if s.strip()))
        if not 1 <= len(symbols) <= 4 or any(s not in RESEARCH_SYMBOLS for s in symbols):
            return []
        return symbols

    def ai_test(self, data: dict) -> tuple[bool, str]:
        with self.lock:
            if not self.connected or not self.demo:
                return False, 'AI анализ е допустим само след MT5 DEMO връзка.'
            if self.running or self.ai_busy or self._start_pending:
                return False, 'Има активна търговия или анализ.'
            if self.auth_state != 'connected':
                return False, 'ChatGPT не е потвърден. Натисни „Провери ChatGPT връзката“ или „Свържи ChatGPT“.'
            symbols = self._symbols(data)
            if not symbols:
                return False, 'Разрешени research символи: ' + ', '.join(RESEARCH_SYMBOLS)
            self._start_ai(symbols, auto_start=False)
            return True, 'AI анализът стартира отделно от браузъра. Не отваря поръчки.'

    def start_demo(self, data: dict) -> tuple[bool, str]:
        with self.lock:
            if not self.connected or not self.demo:
                return False, 'Само проверена DEMO сметка може да бъде активирана.'
            if self.running or self.ai_busy or self._start_pending:
                return False, 'Вече има активно изпълнение.'
            if data.get('confirmation') != 'DEMO ONLY':
                return False, 'Изисква се изрично потвърждение DEMO ONLY.'
            if self.auth_state != 'connected':
                return False, 'Няма проверена ChatGPT сесия. Автоматична търговия е блокирана.'
            symbols = self._symbols(data)
            if not symbols:
                return False, 'Използвай до 4 от разрешените символи.'
            self._start_ai(symbols, auto_start=True)
            return True, 'Започна AI проверка; поръчки са забранени до успешното ѝ приключване.'

    def _start_ai(self, symbols: list[str], *, auto_start: bool):
        self._generation += 1
        gen = self._generation
        self._ai_cancel = threading.Event()
        self.ai_busy = True
        self.ai_stage = 'research'
        self.ai_status = 'TradingAgents стартира за ' + ', '.join(symbols)
        self.ai_symbols = list(symbols)
        self.ai_results = [
            {'symbol': symbol, 'proxy': RESEARCH_SYMBOLS[symbol], 'status': 'QUEUED',
             'action': None, 'reason': '', 'steps': []}
            for symbol in symbols
        ]
        self._log('TradingAgents се изпълнява в отделен процес. UI остава достъпен.')
        threading.Thread(target=self._ai_run, args=(gen, symbols, auto_start, self._ai_cancel),
                         name='TradingAI-ChildSupervisor', daemon=True).start()

    def _ai_run(self, generation: int, symbols: list[str], auto_start: bool,
                cancel: threading.Event):
        # Isolate each batch. A cancelled child or a previous run cannot
        # replace a report used by this batch or grant permission to trade.
        folder = self.worker.store.file.parent / 'ai_reports' / secrets.token_hex(16)
        for index, symbol in enumerate(symbols):
            with self.lock:
                if cancel.is_set() or generation != self._generation:
                    return
                self.ai_status = f'TradingAgents анализира {symbol} ({index + 1}/{len(symbols)}).'
                self._log(self.ai_status)
                row = dict(self.ai_results[index])
            row.update(status='RUNNING', started_at=time.time(), timeout_seconds=AI_TIMEOUT_SECONDS)
            with self.lock:
                if cancel.is_set() or generation != self._generation:
                    return
                self.ai_results[index] = dict(row)
            row = self._research_symbol(symbol, folder, row, index, generation, cancel)
            with self.lock:
                if cancel.is_set() or generation != self._generation:
                    return
                self.ai_results[index] = row
                self._log(f"{symbol} · {row['status']} · {row['duration_seconds']:.1f}s · "
                          + (row['reason'] or row['action']))
        with self.lock:
            if cancel.is_set() or generation != self._generation:
                return
            success = all(row['status'] == 'SUCCESS' for row in self.ai_results)
            self.ai_busy = False
            self.ai_stage = 'completed' if success else 'failed'
            self.ai_status = ' · '.join(
                f"{row['symbol']} {row['action'] if row['status'] == 'SUCCESS' else row['status']}"
                for row in self.ai_results
            )
            if not success:
                self.ai_status += ' · DEMO остава спрян.'
            self._log(self.ai_status)
            today = datetime.now(timezone.utc).date().isoformat()
            if (auto_start and success and self.connected and self.demo and self.auth_state == 'connected'
                    and all(row['date_utc'] == today for row in self.ai_results)):
                self._start_pending = True
                self.worker.send('start', symbols=symbols, ai_report_dir=folder, cancel=cancel)
                self._log('DEMO изпълнението е заявено. MT5 брокерските лимити остават задължителни.')

    def _research_symbol(self, symbol, folder, row, index, generation, cancel):
        started = time.monotonic()
        diagnostic_path = folder / f'{symbol}.progress.json'
        proc = None
        diagnostic = {}
        try:
            kwargs = dict(stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            if sys.platform == 'win32':
                kwargs['creationflags'] = subprocess.CREATE_NO_WINDOW
            proc = subprocess.Popen(ai_child_command('research', symbol, str(folder)), **kwargs)
            with self.lock:
                if cancel.is_set() or generation != self._generation:
                    proc.terminate()
                else:
                    self._ai_process = proc
            while True:
                try:
                    code = proc.wait(timeout=min(1, max(0, AI_TIMEOUT_SECONDS - (time.monotonic() - started))))
                    break
                except subprocess.TimeoutExpired:
                    diagnostic = self._read_progress(diagnostic_path, diagnostic)
                    row['steps'] = diagnostic.get('steps', [])
                    with self.lock:
                        if cancel.is_set() or generation != self._generation:
                            proc.kill()
                            return row
                        self.ai_results[index] = dict(row)
                    if time.monotonic() - started >= AI_TIMEOUT_SECONDS:
                        proc.kill()
                        proc.wait(timeout=10)
                        row.update(status='FAILED', reason=f'Анализът надхвърли лимита от {AI_TIMEOUT_SECONDS} секунди.')
                        return row
            diagnostic = self._read_progress(diagnostic_path, diagnostic)
            row['steps'] = diagnostic.get('steps', [])
            if code != 0:
                row.update(status='FAILED', reason=diagnostic.get('error') or f'AI процесът приключи с код {code}, без диагностичен отчет.')
                return row
            try:
                path, = folder.glob(f'{symbol}_*.json')
                out = json.loads(path.read_text(encoding='utf8'))
                issued = float(out['generated_at_epoch'])
                if not (out['market'] == symbol and out['proxy'] == RESEARCH_SYMBOLS[symbol]
                        and out['provider'] == 'chatgpt' and out['approved'] is False
                        and path.name == f"{symbol}_{out['date_utc']}.json"
                        and row['started_at'] - 1 <= issued <= time.time() + 1
                        and ((out['status'] == 'SUCCESS' and out['action'] in ACTIONS)
                             or (out['status'] == 'UNRESOLVED' and out['action'] == 'UNRESOLVED' and out['reason']))):
                    raise ValueError('unverified report')
                row.update({key: out[key] for key in ('status', 'action', 'reason', 'raw_decision', 'date_utc')})
            except (ValueError, OSError, KeyError, TypeError, UnicodeError):
                row.update(status='FAILED', reason='AI процесът не върна нов валиден отчет за този инструмент.')
        except (OSError, ValueError, subprocess.TimeoutExpired) as exc:
            phase = 'стартиране' if proc is None else 'наблюдение'
            row.update(status='FAILED', reason=f'Грешка при {phase} на AI процеса ({type(exc).__name__}).')
        finally:
            if proc is not None and proc.poll() is None:
                try:
                    proc.kill()
                    proc.wait(timeout=10)
                except (OSError, subprocess.TimeoutExpired):
                    pass
            with self.lock:
                if proc is not None and self._ai_process is proc:
                    self._ai_process = None
            row.update(finished_at=time.time(), duration_seconds=round(time.monotonic() - started, 2))
        return row

    @staticmethod
    def _read_progress(path: Path, previous: dict) -> dict:
        try:
            return json.loads(path.read_text(encoding='utf8'))
        except (OSError, ValueError):
            return previous

    def verify_auth(self) -> tuple[bool, str]:
        """Verify the *persisted* upstream credential in a child, not a UI guess."""
        with self.lock:
            if self.ai_busy:
                return False, 'AI процесът работи. Натисни STOP само ако искаш да го прекратиш.'
            self._generation += 1
            gen = self._generation
            cancel = threading.Event()
            self._ai_cancel = cancel
            self.ai_busy = True
            self.auth_state = 'checking'
            self.auth_message = 'Проверявам дали TradingAgents има валиден ChatGPT токен…'
            self.ai_stage = 'auth_check'
            self.ai_status = self.auth_message
            threading.Thread(target=self._auth_worker, args=(gen, cancel, False),
                             name='TradingAI-AuthCheck', daemon=True).start()
            return True, 'Проверявам съществуващата сесия без нов вход и без сделки.'

    def login_ai(self) -> tuple[bool, str]:
        with self.lock:
            if self.ai_busy:
                return False, 'Друг AI процес вече работи.'
            self._generation += 1
            gen = self._generation
            cancel = threading.Event()
            self._ai_cancel = cancel
            self.ai_busy = True
            self.auth_state = 'checking'
            self.auth_message = 'Входът е в процес. Върни се в Trading AI след потвърждението.'
            self.ai_stage = 'login'
            self.ai_status = self.auth_message
            threading.Thread(target=self._auth_worker, args=(gen, cancel, True),
                             name='TradingAI-Login', daemon=True).start()
            return True, 'Отваря се официалната страница за удостоверяване.'

    @staticmethod
    def _auth_error_message(code: int | None, login: bool) -> str:
        # Only fixed, non-sensitive messages. Never expose OAuth code/URL/token.
        if code == 10:
            return 'Няма запазен ChatGPT вход. Натисни „Свържи ChatGPT“.'
        if code == 11:
            return 'Съществуващата сесия не може да се поднови. Провери интернет и опитай „Провери връзката“.'
        if code == 31:
            return 'OpenAI не отговори при издаването на токен. Опитай отново по-късно.'
        if code == 32:
            return 'OpenAI не потвърди удостоверяването. Възможно е разрешението да е отказано или изтекло.'
        if code == 34:
            return 'Страницата за вход е приключила, но валиден токен не е записан.'
        if code is None:
            return 'Проверката на ChatGPT надхвърли времето и беше прекратена.'
        return 'ChatGPT удостоверяването не успя. Виж „Логове“; брокерските данни не са променени.'

    def _auth_worker(self, generation: int, cancel: threading.Event, login: bool):
        proc = None
        code = None
        try:
            kwargs = dict(stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            if sys.platform == 'win32':
                kwargs['creationflags'] = subprocess.CREATE_NO_WINDOW
            proc = subprocess.Popen(ai_child_command('login' if login else 'auth-check'), **kwargs)
            with self.lock:
                if cancel.is_set() or generation != self._generation:
                    proc.terminate()
                else:
                    self._ai_process = proc
            try:
                proc.wait(timeout=240 if login else 50)
                code = proc.returncode
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=10)
        except (OSError, subprocess.TimeoutExpired):
            code = 99
        finally:
            with self.lock:
                if self._ai_process is proc:
                    self._ai_process = None
                if cancel.is_set() or generation != self._generation:
                    return
                self.ai_busy = False
                if code == 0:
                    self.auth_state = 'connected'
                    self.auth_message = 'Запазената ChatGPT сесия е потвърдена от TradingAgents.'
                    self.ai_stage = 'auth_connected'
                else:
                    self.auth_state = 'disconnected' if code in (10, 32, 34) else 'failed'
                    self.auth_message = self._auth_error_message(code, login)
                    self.ai_stage = 'auth_failed'
                self.ai_status = self.auth_message
                self._log(self.auth_message)

    def stop(self) -> tuple[bool, str]:
        # Kill the independent AI process and invalidate any in-flight Start.
        with self.lock:
            self._generation += 1
            self._ai_cancel.set()
            self._start_pending = False
            proc = self._ai_process
            self._ai_process = None
            self.ai_busy = False
            self.ai_stage = 'stopped'
            self.ai_status = 'STOP: AI анализът е отменен.'
            finished_at = time.time()
            self.ai_results = [
                {**row, 'status': 'CANCELLED', 'reason': 'Анализът е прекратен със STOP.',
                 'finished_at': finished_at,
                 'duration_seconds': round(finished_at - row['started_at'], 2) if 'started_at' in row else None}
                if row['status'] in {'QUEUED', 'RUNNING'} else row
                for row in self.ai_results
            ]
            if self.auth_state == 'checking':
                self.auth_state = 'unknown'
                self.auth_message = 'ChatGPT проверката е прекъсната; провери сесията отново.'
            self.worker.request_stop()
            self._log('STOP: нови демо поръчки няма да се заявяват; отворените остават при брокера.')
        if proc and proc.poll() is None:
            try:
                proc.terminate()
            except OSError:
                pass
        return True, 'STOP е подаден. Виж реалните позиции в MetaTrader 5.'

    def shutdown(self):
        self.stop()
        self.worker.send('shutdown')
        self._closed = True


class AppServer(ThreadingHTTPServer):
    allow_reuse_address = False
    daemon_threads = True

    def __init__(self, address: tuple, controller: Controller):
        if address[0] != HOST:
            raise ValueError('Browser bridge MUST bind loopback only')
        super().__init__(address, AppHandler)
        self.controller = controller


class AppHandler(BaseHTTPRequestHandler):
    server: AppServer
    server_version = 'TradingAI/1.0'

    def log_message(self, format: str, *args):
        # No request bodies, credentials, tokens, or IP details in stdout.
        return

    def _valid_host(self):
        return self.headers.get('Host', '') in {f'{HOST}:{self.server.server_port}'}

    def _json(self, status: int, obj: dict):
        blob = json.dumps(obj, ensure_ascii=False, separators=(',', ':')).encode('utf8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(blob)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Content-Security-Policy', "default-src 'none'; frame-ancestors 'none'")
        self.end_headers()
        self.wfile.write(blob)

    def do_GET(self):
        if not self._valid_host():
            return self._json(403, {'error': 'Host rejected'})
        p = urlparse(self.path).path
        if p == '/':
            html = (ROOT / 'browser_ui.html').read_text(encoding='utf-8')
            # Template substitution only for a random server-created secret.
            html = html.replace('__LOCAL_TOKEN__', self.server.controller.session_token)
            payload = html.encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(payload)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Frame-Options', 'DENY')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('Referrer-Policy', 'no-referrer')
            self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; base-uri 'none'; frame-ancestors 'none'; form-action 'none'")
            self.end_headers()
            self.wfile.write(payload)
        elif p == '/api/status':
            if self.headers.get('X-Local-Token') != self.server.controller.session_token:
                return self._json(403, {'error':'Неоторизирана локална заявка.'})
            self._json(200, self.server.controller.status())
        else:
            self._json(404, {'error':'Няма такава страница'})

    def do_POST(self):
        if not self._valid_host() or self.headers.get('Origin') != f'http://{HOST}:{self.server.server_port}':
            return self._json(403, {'error':'Невалидна локална заявка.'})
        if self.headers.get('X-Local-Token') != self.server.controller.session_token:
            return self._json(403, {'error':'Неоторизирана заявка.'})
        if self.headers.get('Content-Type', '').split(';')[0].strip() != 'application/json':
            return self._json(415, {'error':'Използвай application/json'})
        try:
            length = int(self.headers.get('Content-Length','0'))
        except ValueError:
            length=0
        if not 2 <= length <= MAX_BODY:
            return self._json(413, {'error':'Невалидна големина на заявката.'})
        try:
            data = json.loads(self.rfile.read(length))
            if not isinstance(data, dict):
                raise ValueError('bad object')
        except (UnicodeError, ValueError):
            return self._json(400, {'error':'Невалидни данни.'})
        path = urlparse(self.path).path
        c = self.server.controller
        routes = {
            '/api/connect': lambda: c.connect(data),
            '/api/attach': lambda: c.attach_current(data),
            '/api/check': lambda: c.diagnose(data),
            '/api/ai/test': lambda: c.ai_test(data),
            '/api/ai/login': c.login_ai,
            '/api/ai/auth-check': c.verify_auth,
            '/api/start': lambda: c.start_demo(data),
            '/api/stop': c.stop,
        }
        if path == '/api/exit':
            c.stop()
            self._json(200, {'ok': True, 'message': 'Локалното приложение се затваря.'})
            threading.Thread(target=self.server.shutdown, daemon=True).start()
            return
        fn = routes.get(path)
        if fn is None:
            return self._json(404, {'error':'Няма такава операция.'})
        ok, message = fn()
        self._json(200 if ok else 409, {'ok':ok,'message':message})


def run(port: int = PORT, *, open_browser: bool = True):
    c = Controller()
    server = AppServer((HOST,port),c)
    url = f'http://{HOST}:{server.server_port}/'
    if open_browser:
        threading.Timer(0.9, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever(poll_interval=.3)
    finally:
        c.shutdown()
        server.server_close()


if __name__ == '__main__':
    run()
