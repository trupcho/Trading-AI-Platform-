"""Portable desktop browser bridge, and isolated TradingAgents child process."""
from __future__ import annotations
from pathlib import Path
import sys
import threading
import time


def _research_child(symbol: str, folder: Path) -> int:
    from trading_ai_desktop.ai import research, write_json

    steps = []
    lock = threading.Lock()
    diagnostic = folder / f'{symbol}.progress.json'

    def progress(label):
        with lock:
            steps.append({'step': label, 'at': time.time()})
            write_json(diagnostic, {'steps': steps[-100:]})

    try:
        research(symbol, folder, progress=progress)
        progress('Отчетът е записан')
        return 0
    except Exception as exc:
        # Never persist provider messages, request bodies, prompts or traces.
        code = getattr(exc, 'status_code', None)
        name = type(exc).__name__
        reason = {
            'ChatGPTUnreachable': 'ChatGPT услугата е недостъпна',
            'ChatGPTAuthError': 'ChatGPT сесията е невалидна или е изтекла',
            'AuthenticationError': 'ChatGPT отказа удостоверяването',
            'PermissionDeniedError': 'ChatGPT отказа достъп до модела или заявката',
            'NotFoundError': 'Доставчикът не намери модела или ресурса',
            'RateLimitError': 'Достигнат е лимитът на ChatGPT',
            'APITimeoutError': 'Заявка към ChatGPT надхвърли времето',
            'APIConnectionError': 'Връзката към ChatGPT е прекъсната',
            'ModuleNotFoundError': 'Липсва зависимост на TradingAgents',
            'GraphRecursionError': 'Графът достигна лимита за стъпки',
        }.get(name, 'Грешка в TradingAgents')
        error = f'{reason} ({name})'
        if type(code) is int and 400 <= code <= 599:
            error += f', HTTP {code}'
        write_json(diagnostic, {'steps': steps[-100:], 'error': error})
        return 33


def _ai_child(argv: list[str]):
    """No auth URLs/tokens reach stdout, logs, or browser API."""
    if not argv:
        return 2
    kind = argv[0]
    try:
        if kind == 'research' and len(argv) == 3:
            return _research_child(argv[1], Path(argv[2]))
        if kind == 'auth-check' and len(argv) == 1:
            from trading_ai_desktop.ai import verified_chatgpt_session
            return 0 if verified_chatgpt_session() else 10
        if kind == 'login' and len(argv) == 1:
            from trading_ai_desktop.ai import sign_in_chatgpt, verified_chatgpt_session
            sign_in_chatgpt(lambda text: None)
            return 0 if verified_chatgpt_session() else 34
        return 2
    except Exception as exc:
        # Upstream ChatGPTUnreachable and ChatGPTAuthError are safe *types*;
        # never return raw provider messages, tokens, emails or callback URLs.
        name = type(exc).__name__
        if name == 'ChatGPTUnreachable':
            return 31 if kind == 'login' else 11
        if name == 'ChatGPTAuthError':
            return 32 if kind == 'login' else 10
        return 33


if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == '--ai-child':
        raise SystemExit(_ai_child(sys.argv[2:]))
    if '--selftest' in sys.argv:
        from trading_ai_desktop.ai import tradingagents_installed, tradingagents_config
        from trading_ai_desktop.browser_server import AppServer, HOST
        from trading_ai_desktop.browser_server import ROOT
        ok = tradingagents_installed() and tradingagents_config().get('llm_provider') == 'chatgpt'
        ok = ok and (ROOT / 'browser_ui.html').is_file()
        raise SystemExit(0 if ok else 9)
    from trading_ai_desktop.browser_server import run
    run()
