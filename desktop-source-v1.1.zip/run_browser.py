"""Portable desktop browser bridge, and isolated TradingAgents child process."""
from __future__ import annotations
import json
from pathlib import Path
import sys


def _ai_child(argv: list[str]):
    """No auth URLs/tokens reach stdout, logs, or browser API."""
    if not argv:
        return 2
    kind = argv[0]
    try:
        if kind == 'research' and len(argv) == 3:
            from trading_ai_desktop.ai import research
            research(argv[1], Path(argv[2]))
            return 0
        if kind == 'auth-check' and len(argv) == 1:
            from trading_ai_desktop.ai import verified_chatgpt_session
            return 0 if verified_chatgpt_session() else 10
        if kind == 'login' and len(argv) == 1:
            from trading_ai_desktop.ai import sign_in_chatgpt, verified_chatgpt_session
            sign_in_chatgpt(lambda text: None)
            return 0 if verified_chatgpt_session() else 34
        return 2
    except Exception as exc:
        # Upstream ChatGPTUnreachable and ChatGPTAuthError are safe *types*;
        # never return raw provider messages, tokens, emails or callback URLs.
        name = type(exc).__name__
        if name == 'ChatGPTUnreachable':
            return 31 if kind == 'login' else 11
        if name == 'ChatGPTAuthError':
            return 32 if kind == 'login' else 10
        return 33


if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == '--ai-child':
        raise SystemExit(_ai_child(sys.argv[2:]))
    if '--selftest' in sys.argv:
        from trading_ai_desktop.ai import tradingagents_installed, tradingagents_config
        from trading_ai_desktop.browser_server import AppServer, HOST
        from trading_ai_desktop.browser_server import ROOT
        ok = tradingagents_installed() and tradingagents_config().get('llm_provider') == 'chatgpt'
        ok = ok and (ROOT / 'browser_ui.html').is_file()
        raise SystemExit(0 if ok else 9)
    from trading_ai_desktop.browser_server import run
    run()
