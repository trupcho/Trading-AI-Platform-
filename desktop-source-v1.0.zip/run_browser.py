"""Portable desktop browser bridge, and isolated TradingAgents child process."""
from __future__ import annotations
import json
from pathlib import Path
import sys


def _ai_child(argv: list[str]):
    if not argv:
        return 2
    kind = argv[0]
    try:
        if kind == 'research' and len(argv) == 3:
            from trading_ai_desktop.ai import research
            report = research(argv[1], Path(argv[2]))
            # Result is atomically stored in report JSON; no console/stdout required.
            return 0
        if kind == 'login' and len(argv) == 1:
            from trading_ai_desktop.ai import sign_in_chatgpt
            sign_in_chatgpt(lambda text: None)
            # The caller only checks the child exit code.
            return 0
        return 2
    except Exception:
        # Never print user credentials, OAuth URLs, tokens or research providers' tracebacks.
        return 7


if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == '--ai-child':
        raise SystemExit(_ai_child(sys.argv[2:]))
    if '--selftest' in sys.argv:
        from trading_ai_desktop.ai import tradingagents_installed, tradingagents_config
        from trading_ai_desktop.browser_server import AppServer, HOST
        from trading_ai_desktop.browser_server import ROOT
        ok = tradingagents_installed() and tradingagents_config().get('llm_provider') == 'chatgpt'
        ok = ok and (ROOT / 'browser_ui.html').is_file()
        raise SystemExit(0 if ok else 9)
    from trading_ai_desktop.browser_server import run
    run()
